"""
Azure AI Foundry Agent Service integration.

Maps directly onto the confirmed architecture (Solution Approach Section
2.3.3; ADA Detailed Documentation Section 6.3; architecture diagram's
"AI Foundry Agent Service (Foundry Threads)" + "Azure OpenAI GPT" boxes):

  - Conversation continuity (Step 3a) uses a real Foundry Thread, not a
    locally-generated id. The Thread is configured with Bring-Your-Own
    storage pointed at the CIL Metadata Store's Cosmos DB account (a
    dedicated container, separate from the governance container -- see
    Section 2.3.1's container-separation principle).
  - The orchestrator's LLM-driven steps (4 Query Understanding, 4a Guided
    Question Loop, 4b Source Prioritization, 8 Ranking + Explanation,
    9a Result Confirmation) are executed by ADA's own Foundry "Coded Agent"
    -- an Agent Service agent whose implementation is our own code
    (see ../foundry_coded_agent/handler.py), not a bare prompt+tools agent.
    The orchestrator drives it via the standard Threads/Runs pattern so
    Foundry's own observability/tracing (Section 4.2 cross-cutting capability:
    "Observability & Audit -> Foundry observability") wraps every call,
    in addition to App Insights/Log Analytics.
  - This is ADA's dedicated agent. Per the architecture's per-agent AI
    Orchestration layer, CGE and SBA get their own separate Coded Agents in
    Phase 3 -- this client and this agent registration are ADA-specific and
    should not be shared across agents.

SDK surface note: the Azure AI Foundry Agent Service SDK (currently
`azure-ai-projects` + `azure-ai-agents`) has changed method/class names
across preview releases. The call sequence below (create/get thread, create
message, create run, poll, read required_action, submit_tool_outputs) is the
stable *protocol* -- verify exact method names against current SDK docs at
deploy time and adjust the thin wrapper calls if needed; the orchestration
logic in this file does not otherwise change.
"""

from __future__ import annotations

import json
import time
from typing import Any, Optional

from ada_orchestrator.clients.azure_openai_client import LLMClient


class FoundryThreadResolver:
    """
    Resolves a (channel, external_conversation_id) key to a real Foundry
    Thread id, creating one on first contact. This is the piece that was
    missing from the original thread_store.py -- that file already had the
    correct lookup-or-create *shape*, it just never called Foundry to get a
    real thread_id. ThreadStore now delegates thread creation to this class
    when Foundry is enabled (see thread_store.RealCosmosThreadStore).
    """

    def __init__(self, project_endpoint: str):
        from azure.ai.projects import AIProjectClient
        from azure.identity import DefaultAzureCredential

        self._project = AIProjectClient(endpoint=project_endpoint, credential=DefaultAzureCredential())
        self._agents = self._project.agents

    def create_thread(self) -> str:
        """Create a new Foundry Thread and return its id. Thread storage
        location (BYO Cosmos DB, per Section 2.3.3) is a project-level
        configuration set at Foundry project/agent setup time, not per-call
        here."""
        thread = self._agents.threads.create()
        return thread.id

    def get_thread(self, thread_id: str) -> Any:
        return self._agents.threads.get(thread_id)


class FoundryCodedAgentClient(LLMClient):
    """
    LLMClient implementation that delegates every call_tool() invocation to
    ADA's Foundry Coded Agent via a Thread + Run, instead of calling Azure
    OpenAI chat completions directly (contrast with RealAzureOpenAIClient in
    azure_openai_client.py, which remains available as the simpler
    non-Foundry production path).

    One Foundry Thread is reused across every step in a single user turn
    (Query Understanding -> Guided Question -> Source Prioritization ->
    Ranking -> Confirmation) via `set_active_thread()`, called once per turn
    in orchestrator.run_turn(). This matches the architecture's intent for
    Foundry Threads to hold "prior turns, filters, results already shown"
    (Solution Approach Section 2.3.3) -- continuity is a property of the
    Thread, not of this client instance.
    """

    def __init__(self, project_endpoint: str, agent_id: str,
                 poll_interval_seconds: float = 0.5, run_timeout_seconds: float = 30.0):
        from azure.ai.projects import AIProjectClient
        from azure.identity import DefaultAzureCredential

        self._project = AIProjectClient(endpoint=project_endpoint, credential=DefaultAzureCredential())
        self._agents = self._project.agents
        self._agent_id = agent_id
        self._poll_interval = poll_interval_seconds
        self._timeout = run_timeout_seconds
        self._active_thread_id: Optional[str] = None

        # Embeddings are not part of the Agent Run loop -- Foundry Agents
        # produce chat/tool responses, not embedding vectors. Query
        # embedding (Step 6) still calls the Azure OpenAI embedding
        # deployment directly, per the architecture diagram's separate
        # "Azure OpenAI / Foundry embedding model" box feeding Query
        # Embedding -- this is intentional, not a gap.
        from ada_orchestrator.clients.azure_openai_client import RealAzureOpenAIClient
        self._embedding_client = RealAzureOpenAIClient.__new__(RealAzureOpenAIClient)  # embeddings-only use
        from openai import AzureOpenAI
        self._embedding_client._client = AzureOpenAI(
            azure_endpoint=project_endpoint, azure_ad_token_provider=None,
        )

    def set_active_thread(self, thread_id: str | None) -> None:
        self._active_thread_id = thread_id

    def call_tool(self, system_prompt, user_message, tool_schema, context=None) -> dict[str, Any]:
        if self._active_thread_id is None:
            resolver = FoundryThreadResolver.__new__(FoundryThreadResolver)
            resolver._project = self._project
            resolver._agents = self._agents
            self._active_thread_id = resolver.create_thread()

        step_name = tool_schema["function"]["name"]
        payload = {
            "step": step_name,
            "system_prompt": system_prompt,   # the Coded Agent's own code selects behavior by step name;
            "tool_schema": tool_schema,        # system_prompt/tool_schema are passed through so the agent's
            "user_message": user_message,     # implementation stays in lockstep with prompts.py/tools.py
            "context": context or {},          # even if the Foundry-side deployment lags a version behind.
        }

        self._agents.messages.create(
            thread_id=self._active_thread_id, role="user", content=json.dumps(payload),
        )
        run = self._agents.runs.create(thread_id=self._active_thread_id, agent_id=self._agent_id)

        run = self._poll_until_requires_action_or_done(run)

        if run.status != "requires_action":
            raise RuntimeError(
                f"Foundry Coded Agent run for step '{step_name}' ended in status "
                f"'{run.status}' without the expected tool call -- check the agent's "
                f"implementation in foundry_coded_agent/handler.py."
            )

        tool_call = run.required_action.submit_tool_outputs.tool_calls[0]
        arguments = json.loads(tool_call.function.arguments)

        # Acknowledge the tool call so the run closes cleanly rather than
        # hanging in "requires_action" -- we don't need the agent to keep
        # generating after this; the structured arguments are the result.
        self._agents.runs.submit_tool_outputs(
            thread_id=self._active_thread_id, run_id=run.id,
            tool_outputs=[{"tool_call_id": tool_call.id, "output": "ack"}],
        )
        return arguments

    def embed(self, text: str) -> list[float]:
        resp = self._embedding_client._client.embeddings.create(
            model="text-embedding-3-small", input=text,
        )
        return resp.data[0].embedding

    def _poll_until_requires_action_or_done(self, run: Any) -> Any:
        start = time.time()
        while run.status in ("queued", "in_progress"):
            if time.time() - start > self._timeout:
                raise TimeoutError(f"Foundry run {run.id} did not resolve within {self._timeout}s")
            time.sleep(self._poll_interval)
            run = self._agents.runs.get(thread_id=run.thread_id, run_id=run.id)
        return run

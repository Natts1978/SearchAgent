"""
Azure AI Search client -- ADA's RAG store. Query time only ever hits this
index, never the live source systems (Approach A, confirmed architecture).

governed_filter shape (from steps/step5_governance_filter.py), aligned to
the actual Cosmos schema's per-profile structure:
  {
    "market": str, "approved_repositories": [{"contentProfile","repositoryId","priority"}, ...],
    "excluded_repositories": [...], "eligibility_gates": {profile: {"primary":[...], "secondary":[...]}},
    "rights_constraints": {...}, "asset_format": str|None, "destination_use": str|None,
    "subject_terms": [str], "person_query": str|None, "query_intent": str,
  }
"""

from __future__ import annotations

from typing import Any

from ada_orchestrator.models import CandidateAsset


class SearchClient:
    def hybrid_search(
        self,
        query_text: str,
        query_vector: list[float],
        governed_filter: dict[str, Any],
        top_k: int = 10,
    ) -> list[CandidateAsset]:
        raise NotImplementedError


class RealAzureSearchClient(SearchClient):
    """Production client. Requires `azure-search-documents`."""

    def __init__(self, endpoint: str, api_key: str, index_name: str):
        from azure.core.credentials import AzureKeyCredential
        from azure.search.documents import SearchClient as _SDKSearchClient

        self._client = _SDKSearchClient(
            endpoint=endpoint, index_name=index_name, credential=AzureKeyCredential(api_key)
        )

    def hybrid_search(self, query_text, query_vector, governed_filter, top_k=10) -> list[CandidateAsset]:
        odata_filter = _build_odata_filter(governed_filter)
        results = self._client.search(
            search_text=query_text,
            vector_queries=[{"vector": query_vector, "k_nearest_neighbors": top_k, "fields": "assetVector"}],
            filter=odata_filter,
            top=top_k,
        )
        return [_doc_to_candidate(doc) for doc in results]


def _build_odata_filter(governed_filter: dict[str, Any]) -> str:
    clauses = ["restrictedFlag eq false"]
    approved_repo_ids = [r["repositoryId"] for r in governed_filter.get("approved_repositories", [])]
    if approved_repo_ids:
        vals = " or ".join(f"repositoryId eq '{rid}'" for rid in approved_repo_ids)
        clauses.append(f"({vals})")
    return " and ".join(clauses)


def _doc_to_candidate(doc: dict[str, Any]) -> CandidateAsset:
    return CandidateAsset(
        asset_id=doc["assetId"], title=doc["title"], title_source=doc.get("titleSource", "source"),
        description=doc.get("description", ""), description_source=doc.get("descriptionSource", "source"),
        source_system=doc["sourceSystem"], source_url=doc.get("sourceUrl", ""), asset_type=doc.get("assetType", ""),
        content_profile=doc.get("contentProfile", ""),
        topic=doc.get("topic", []), channel=doc.get("channel", []),
        audience=doc.get("audience", []), market=doc.get("market", []),
        approval_status=doc.get("approvalStatus"), lifecycle_status=doc.get("lifecycleStatus"),
        publication_status=doc.get("publicationStatus"),
        owner=doc.get("owner"), restricted_flag=doc.get("restrictedFlag", False),
        missing_metadata_fields=doc.get("missingMetadataFields", []),
        relevance_score=doc.get("@search.score", 0.0),
        license_restriction=doc.get("licenseRestriction"), license_type=doc.get("licenseType"),
        has_template_link=doc.get("hasTemplateLink", False), template_file_url=doc.get("templateFileUrl"),
        template_file_type=doc.get("templateFileType"), template_version=doc.get("templateVersion"),
        is_template_link_current=doc.get("isTemplateLinkCurrent"),
        first_name=doc.get("firstName"), last_name=doc.get("lastName"),
        job_title=doc.get("jobTitle"), office_location=doc.get("officeLocation"),
    )


class MockSearchClient(SearchClient):
    """
    In-memory catalog spanning all four Phase-1 content profiles (creativeAsset,
    publishedWebContent, peopleOfficeProfile, brandGuidelineReference) so the
    orchestrator's per-profile filtering/eligibility/ranking logic can be
    exercised end-to-end, including template-link handling and a people-lookup
    result -- neither of which existed in the earlier, source-system-only mock.
    """

    _CATALOG: list[dict[str, Any]] = [
        # -- creativeAsset (BMC DAM) --------------------------------------
        dict(asset_id="dam-001", title="AI Transformation Hero Image", title_source="source",
             description="Approved hero image depicting AI-driven business transformation, CFO-facing.",
             description_source="source", source_system="AdobeDAM", content_profile="creativeAsset",
             repository_id="bmc-dam-global",
             source_url="https://dam.example.com/assets/dam-001", asset_type="image",
             topic=["AI transformation"], channel=["webpage", "social post"], audience=["CFO"], market=["US"],
             approval_status="approved", lifecycle_status="active", owner="Brand Team US",
             license_restriction="none", license_type="perpetual"),
        dict(asset_id="dam-002", title="Resilience & Risk Management Report Cover", title_source="source",
             description="Report cover asset for resilience and risk management content, UK market.",
             description_source="source", source_system="AdobeDAM", content_profile="creativeAsset",
             repository_id="bmc-dam-global",
             source_url="https://dam.example.com/assets/dam-002", asset_type="document",
             topic=["resilience/risk management"], channel=["client presentation"], audience=["CFO"], market=["UK"],
             approval_status="approved", lifecycle_status="active", owner="Brand Team UK",
             license_restriction="none", license_type="perpetual"),
        dict(asset_id="dam-003", title="Generic Approved Stock Photo -- Office Collaboration", title_source="source",
             description="General-purpose collaboration image, broadly approved, no specific topic tag.",
             description_source="source", source_system="AdobeDAM", content_profile="creativeAsset",
             repository_id="bmc-dam-global",
             source_url="https://dam.example.com/assets/dam-003", asset_type="image",
             topic=[], channel=["webpage", "social post", "email"], audience=[], market=["US", "UK"],
             approval_status="approved", lifecycle_status="active", owner="Brand Team US",
             license_restriction="none", license_type="perpetual"),

        # -- publishedWebContent (EY.com) ---------------------------------
        dict(asset_id="eycom-010", title="EY.com Transformation Landing Page Asset", title_source="source",
             description="Web-optimized image for the ey.com AI transformation landing page.",
             description_source="source", source_system="EYcom", content_profile="publishedWebContent",
             repository_id="eycom-sites",
             source_url="https://ey.com/assets/eycom-010", asset_type="image",
             topic=["AI transformation"], channel=["ey.com webpage"], audience=[], market=["US"],
             approval_status="approved", lifecycle_status="active", owner="Digital Team",
             publication_status="published"),

        # -- brandGuidelineReference (SharePoint Branding Zone) -----------
        dict(asset_id="sp-101", title="Business Card Template Pack", title_source="ai_generated",
             description="AI-generated summary: an editable business card template following EY brand guidelines.",
             description_source="ai_generated", source_system="SharePoint", content_profile="brandGuidelineReference",
             repository_id="branding-zone-us",
             source_url="https://sharepoint.example.com/brandingzone/sp-101", asset_type="template",
             topic=["brand guidance"], channel=["client presentation"], audience=[], market=["US"],
             approval_status="approved", lifecycle_status="active", owner=None,
             missing_metadata_fields=["owner"], publication_status="published",
             has_template_link=True, template_file_url="https://sharepoint.example.com/brandingzone/files/business-card.indd",
             template_file_type="indd", template_version="v3", is_template_link_current=True),
        dict(asset_id="sp-102", title="Logo Usage Guidance", title_source="source",
             description="Do/avoid examples for EY logo usage across channels.",
             description_source="source", source_system="SharePoint", content_profile="brandGuidelineReference",
             repository_id="branding-zone-us",
             source_url="https://sharepoint.example.com/brandingzone/sp-102", asset_type="document",
             topic=["brand guidance"], channel=["internal reference"], audience=[], market=["US"],
             approval_status="approved", lifecycle_status="active", owner="Brand Governance",
             publication_status="published", has_template_link=False),

        # -- peopleOfficeProfile (EY.com Content Fragments) ---------------
        dict(asset_id="cf-201", title="Jane Whitfield -- Office Managing Partner, Chicago", title_source="source",
             description="Office Managing Partner for the Chicago office; Assurance service line.",
             description_source="source", source_system="ContentFragment", content_profile="peopleOfficeProfile",
             repository_id="eycom-people-profiles",
             source_url="https://ey.com/people/jane-whitfield", asset_type="profile",
             topic=[], channel=[], audience=[], market=["US"],
             approval_status="approved", lifecycle_status="active", owner=None,
             publication_status="published",
             first_name="Jane", last_name="Whitfield", job_title="Office Managing Partner",
             office_location="Chicago"),
    ]

    def hybrid_search(self, query_text, query_vector, governed_filter, top_k=10) -> list[CandidateAsset]:
        approved_repo_ids = {r["repositoryId"] for r in governed_filter.get("approved_repositories", [])}
        subject_terms = governed_filter.get("subject_terms", [])
        asset_format = governed_filter.get("asset_format")
        destination = governed_filter.get("destination_use")
        person_query = (governed_filter.get("person_query") or "").lower()
        query_intent = governed_filter.get("query_intent", "unspecified")

        candidates: list[CandidateAsset] = []
        for doc in self._CATALOG:
            if doc["repository_id"] not in approved_repo_ids:
                continue  # not in an approved, included repository for this market/profile

            score = 0.0

            if doc["content_profile"] == "peopleOfficeProfile":
                # People search matches on name/title/office, not topic/format/destination.
                haystack = f"{doc.get('first_name','')} {doc.get('last_name','')} {doc.get('job_title','')} {doc.get('office_location','')}".lower()
                if person_query and any(term in haystack for term in person_query.split()):
                    score += 3.0
                elif query_intent == "peopleProfileLookup":
                    score += 0.2  # weak baseline so a people-intent query without a clean name match still surfaces something
                else:
                    score += 0.05
            else:
                for term in subject_terms:
                    if term and term.lower() in " ".join(doc["topic"]).lower():
                        score += 2.0
                    if term and term.lower() in doc["description"].lower():
                        score += 0.5
                if asset_format and asset_format.lower() == doc["asset_type"].lower():
                    score += 1.0
                if destination and any(destination.lower() in c.lower() for c in doc["channel"]):
                    score += 1.0
                score += 0.1  # baseline so unrelated-but-approved assets can still surface at low rank

            candidates.append(CandidateAsset(
                asset_id=doc["asset_id"], title=doc["title"], title_source=doc["title_source"],
                description=doc["description"], description_source=doc["description_source"],
                source_system=doc["source_system"], content_profile=doc["content_profile"],
                source_url=doc["source_url"], asset_type=doc["asset_type"],
                topic=doc["topic"], channel=doc["channel"], audience=doc.get("audience", []), market=doc.get("market", []),
                approval_status=doc["approval_status"], lifecycle_status=doc["lifecycle_status"],
                publication_status=doc.get("publication_status"), owner=doc.get("owner"),
                restricted_flag=False, missing_metadata_fields=doc.get("missing_metadata_fields", []),
                relevance_score=score,
                license_restriction=doc.get("license_restriction"), license_type=doc.get("license_type"),
                has_template_link=doc.get("has_template_link", False), template_file_url=doc.get("template_file_url"),
                template_file_type=doc.get("template_file_type"), template_version=doc.get("template_version"),
                is_template_link_current=doc.get("is_template_link_current"),
                first_name=doc.get("first_name"), last_name=doc.get("last_name"),
                job_title=doc.get("job_title"), office_location=doc.get("office_location"),
            ))

        candidates.sort(key=lambda c: c.relevance_score, reverse=True)
        return candidates[:top_k]


def get_search_client(use_mock: bool = True, **real_client_kwargs) -> SearchClient:
    if use_mock:
        return MockSearchClient()
    return RealAzureSearchClient(**real_client_kwargs)

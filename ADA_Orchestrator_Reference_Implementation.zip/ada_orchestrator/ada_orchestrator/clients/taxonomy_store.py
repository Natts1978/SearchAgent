"""
CIL Metadata Store client -- aligned to the actual confirmed schema in
CIL_ADA_CosmosDB_Schema_Final_Consolidated.docx ("Final, merged definition
across BMC DAM, EY.com, Content Fragments, and Branding Zone").

Five containers, all in the `cil-metadata-store` Cosmos DB account
(business-owned, per Solution Approach Section 2.2's "BMC owns the brain"
principle):

  repository-content-profiles  (/contentProfile)  -- what each repo contains,
      the intent it serves, its dominant taxonomy, its eligibility gate.
      Every other container refers back to this. Section 3.
  taxonomy-classification      (/domain)           -- controlled vocab per
      taxonomy domain, including queryIntent + detectionCues. Section 4.
  trust-ranking-signals        (/signalType)        -- intentProfileBoost
      (primary ranking driver), templateLinkBoost, sourceDataQualityWeight,
      metadataCompletenessThresholds, audienceMarketMatch. Section 5.
  repository-governance-rules  (/market)            -- approved repos per
      market (each linked to a contentProfile), rights constraints. Section 6.
  source-field-mapping         (/sourceSystem)       -- ingestion-time only;
      ADA's query-time code does not read this container directly (Section 8's
      Query Flow Integration table feeds this into ingestion Step 7, not any
      query-time step) -- included here for completeness/inspection only.

This client intentionally does NOT decide queryIntent or ranking weights
itself -- it only returns what Cosmos DB holds. Classification (Step 4) and
weight application (Step 8) are done by the orchestrator/LLM reading FROM
this store, per the client's explicit hybrid direction: intent can be
inferred automatically (using the detectionCues this store returns) or
supplied directly by the user via a guided question, but the WEIGHTS that
prioritize results always come from here, never from an LLM guess.
"""

from __future__ import annotations

from typing import Any, Optional


class TaxonomyStore:
    def get_taxonomy_domain(self, domain: str) -> dict[str, Any]:
        raise NotImplementedError

    def get_taxonomy_options(self, domain: str) -> list[str]:
        raise NotImplementedError

    def get_query_intent_detection_cues(self) -> dict[str, list[str]]:
        raise NotImplementedError

    def get_content_profile(self, content_profile: str) -> dict[str, Any]:
        raise NotImplementedError

    def get_all_content_profiles(self) -> list[dict[str, Any]]:
        raise NotImplementedError

    def get_governance_rule(self, market: Optional[str]) -> dict[str, Any]:
        raise NotImplementedError

    def get_intent_profile_boost(self) -> dict[str, dict[str, float]]:
        raise NotImplementedError

    def get_template_link_boost(self) -> dict[str, Any]:
        raise NotImplementedError

    def get_source_data_quality_weights(self) -> dict[str, float]:
        raise NotImplementedError

    def get_metadata_completeness_thresholds(self) -> dict[str, Any]:
        raise NotImplementedError

    def get_audience_market_match_signal(self) -> dict[str, Any]:
        raise NotImplementedError

    def get_repository_scope(self, market: Optional[str]) -> list[str]:
        raise NotImplementedError

    def get_approved_approval_statuses(self) -> list[str]:
        raise NotImplementedError

    def get_business_ranking_weights(self) -> dict[str, float]:
        raise NotImplementedError


class RealCosmosTaxonomyStore(TaxonomyStore):
    """
    Reads the five containers directly, using the exact document id /
    partition key conventions shown in the Cosmos schema doc, e.g.:
        repository-content-profiles: id="profile::creativeAsset", partition key value = "creativeAsset"
        taxonomy-classification:     id="taxonomy::queryIntent",  partition key value = "queryIntent"
        trust-ranking-signals:       id="signal::intentProfileBoost", partition key value = "intentProfileBoost"
        repository-governance-rules: id="gov-rule::US", partition key value = "US"
    """

    def __init__(self, endpoint: str, key: str, database: str,
                 content_profiles_container: str = "repository-content-profiles",
                 taxonomy_container: str = "taxonomy-classification",
                 signals_container: str = "trust-ranking-signals",
                 governance_container: str = "repository-governance-rules",
                 field_mapping_container: str = "source-field-mapping"):
        from azure.cosmos import CosmosClient

        db = CosmosClient(endpoint, key).get_database_client(database)
        self._profiles = db.get_container_client(content_profiles_container)
        self._taxonomy = db.get_container_client(taxonomy_container)
        self._signals = db.get_container_client(signals_container)
        self._governance = db.get_container_client(governance_container)
        self._field_mapping = db.get_container_client(field_mapping_container)

    def get_taxonomy_domain(self, domain: str) -> dict[str, Any]:
        doc_id = f"taxonomy::{domain}"
        return self._taxonomy.read_item(item=doc_id, partition_key=domain)

    def get_taxonomy_options(self, domain: str) -> list[str]:
        doc = self.get_taxonomy_domain(domain)
        return [v["value"] for v in doc.get("values", [])]

    def get_query_intent_detection_cues(self) -> dict[str, list[str]]:
        doc = self.get_taxonomy_domain("queryIntent")
        return doc.get("detectionCues", {})

    def get_content_profile(self, content_profile: str) -> dict[str, Any]:
        doc_id = f"profile::{content_profile}"
        return self._profiles.read_item(item=doc_id, partition_key=content_profile)

    def get_all_content_profiles(self) -> list[dict[str, Any]]:
        query = "SELECT * FROM c"
        return list(self._profiles.query_items(query=query, enable_cross_partition_query=True))

    def get_governance_rule(self, market: Optional[str]) -> dict[str, Any]:
        market_key = market or "GLOBAL"
        doc_id = f"gov-rule::{market_key}"
        return self._governance.read_item(item=doc_id, partition_key=market_key)

    def get_intent_profile_boost(self) -> dict[str, dict[str, float]]:
        doc = self._signals.read_item(item="signal::intentProfileBoost", partition_key="intentProfileBoost")
        return doc["boostMatrix"]

    def get_template_link_boost(self) -> dict[str, Any]:
        return self._signals.read_item(item="signal::templateLinkBoost", partition_key="templateLinkBoost")

    def get_source_data_quality_weights(self) -> dict[str, float]:
        doc = self._signals.read_item(item="signal::sourceDataQualityWeight", partition_key="sourceDataQualityWeight")
        return doc["weights"]

    def get_metadata_completeness_thresholds(self) -> dict[str, Any]:
        return self._signals.read_item(
            item="signal::metadataCompletenessThresholds", partition_key="metadataCompletenessThresholds"
        )

    def get_audience_market_match_signal(self) -> dict[str, Any]:
        return self._signals.read_item(item="signal::audienceMarketMatch", partition_key="audienceMarketMatch")

    def get_repository_scope(self, market: Optional[str]) -> list[str]:
        rule = self.get_governance_rule(market)
        return [r["repositoryId"] for r in rule.get("approvedRepositories", []) if r.get("included")]

    def get_approved_approval_statuses(self) -> list[str]:
        return ["approved"]

    def get_business_ranking_weights(self) -> dict[str, float]:
        return {"approved_boost": 1.0}


class MockTaxonomyStore(TaxonomyStore):
    """
    Mirrors the ACTUAL documents shown in the Cosmos schema doc (Sections
    3-6), not a simplified stand-in. Every value below is taken directly
    from the schema's worked examples so the demo genuinely exercises the
    confirmed design (intent boosts, template-link boost, completeness
    penalties, audience/market match, per-market governance).
    """

    _TAXONOMY_DOMAINS: dict[str, dict[str, Any]] = {
        "audience": {
            "domain": "audience",
            "values": [
                {"value": "CFO", "label": "Chief Financial Officer", "active": True},
                {"value": "CIO", "label": "Chief Information Officer", "active": True},
                {"value": "CEO", "label": "Chief Executive Officer", "active": True},
                {"value": "Board", "label": "Board of Directors", "active": True},
            ],
        },
        "market": {"domain": "market", "values": [{"value": v} for v in ["US", "UK", "AU"]]},
        "channel": {"domain": "channel", "values": [{"value": v} for v in
                     ["ey.com webpage", "LinkedIn post", "client presentation", "email", "social post"]]},
        "asset_format": {"domain": "asset_format", "values": [{"value": v} for v in
                          ["image", "document", "video", "template"]]},
        "user_role": {"domain": "user_role", "values": []},
        "queryIntent": {
            "domain": "queryIntent",
            "docType": "taxonomyDomain",
            "values": [
                {"value": "assetReuse", "label": "Find a reusable campaign asset", "primaryProfile": "creativeAsset"},
                {"value": "publishedContentCheck", "label": "Check what's already published", "primaryProfile": "publishedWebContent"},
                {"value": "brandGuidelineLookup", "label": "Find a brand guideline / usage rule", "primaryProfile": "brandGuidelineReference"},
                {"value": "templateRequest", "label": "Get a ready-to-use template for an activity", "primaryProfile": "brandGuidelineReference"},
                {"value": "peopleProfileLookup", "label": "Find a person or office profile", "primaryProfile": "peopleOfficeProfile"},
                {"value": "unspecified", "label": "No clear single intent -- search broadly", "primaryProfile": None},
            ],
            "detectionCues": {
                "assetReuse": ["campaign", "reuse", "approved image", "creative", "asset for"],
                "publishedContentCheck": ["already on ey.com", "published", "does this exist", "duplicate"],
                "brandGuidelineLookup": ["brand guideline", "logo usage", "how do we use", "correct way to"],
                "templateRequest": ["template for", "business card template", "need a template",
                                     "letterhead template", "fill in", "editable file"],
                "peopleProfileLookup": ["bio", "contact", "office location", "who is", "profile for"],
            },
            "detectionNotes": (
                "brandGuidelineLookup and templateRequest both resolve to profile brandGuidelineReference -- "
                "the deciding cue is whether the query names a concrete deliverable (business card, letterhead) "
                "vs. a rule (usage, correct way)."
            ),
        },
    }

    _CONTENT_PROFILES: dict[str, dict[str, Any]] = {
        "creativeAsset": {
            "contentProfile": "creativeAsset", "sourceSystem": "AdobeDAM", "repositoryId": "bmc-dam-global",
            "primaryUserIntent": ["assetReuse", "campaignSourcing"],
            "dominantTaxonomyDimensions": ["campaign", "audience", "market", "channel", "topic"],
            "primaryEligibilityGate": ["licenseRestriction", "licenseType", "originalUse", "embargoExpiryDate"],
            "secondaryEligibilityGate": ["publicationStatus", "lifecycleStatus"],
            "freshnessRelevant": False, "reuseSignalsTracked": True,
        },
        "publishedWebContent": {
            "contentProfile": "publishedWebContent", "sourceSystem": "EYcom", "repositoryId": "eycom-sites",
            "primaryUserIntent": ["publishedContentCheck", "duplicateAvoidance"],
            "dominantTaxonomyDimensions": ["topic", "pageCategory", "pageSubCategory", "serviceLine"],
            "primaryEligibilityGate": ["publicationStatus", "liveURL"],
            "secondaryEligibilityGate": ["excludeFromSearch"],
            "freshnessRelevant": True, "reuseSignalsTracked": False,
        },
        "peopleOfficeProfile": {
            "contentProfile": "peopleOfficeProfile", "sourceSystem": "ContentFragment",
            "repositoryId": "eycom-people-profiles",
            "primaryUserIntent": ["peopleProfileLookup"],
            "dominantTaxonomyDimensions": ["serviceLine", "subServiceLine", "area", "region", "jobTitle"],
            "primaryEligibilityGate": ["publicationStatus"], "secondaryEligibilityGate": [],
            "freshnessRelevant": True, "reuseSignalsTracked": False,
            "notes": "Excluded from the asset-reuse KPI -- a profile lookup is not a marketing-asset reuse event.",
        },
        "brandGuidelineReference": {
            "contentProfile": "brandGuidelineReference", "sourceSystem": "SharePoint",
            "repositoryId": "branding-zone-us",
            "primaryUserIntent": ["brandGuidelineLookup", "complianceReference", "templateRequest"],
            "dominantTaxonomyDimensions": ["pageCategory", "pageSubCategory", "topic"],
            "primaryEligibilityGate": ["excludeFromSearch"],
            "secondaryEligibilityGate": ["publicationStatus", "isTemplateLinkCurrent"],
            "freshnessRelevant": False, "reuseSignalsTracked": False,
        },
    }

    _GOVERNANCE_RULES: dict[str, dict[str, Any]] = {
        "US": {
            "market": "US",
            "approvedRepositories": [
                {"contentProfile": "creativeAsset", "repositoryId": "bmc-dam-global", "priority": 1, "included": True},
                {"contentProfile": "publishedWebContent", "repositoryId": "eycom-sites", "priority": 1, "included": True},
                {"contentProfile": "peopleOfficeProfile", "repositoryId": "eycom-people-profiles", "priority": 2, "included": True},
                {"contentProfile": "brandGuidelineReference", "repositoryId": "branding-zone-us", "priority": 1, "included": True},
                {"contentProfile": "creativeAsset", "repositoryId": "brightcove-global", "priority": 3, "included": False,
                 "exclusionReason": "Metadata/governance cleanup in progress, ETA ~Sep 2026"},
            ],
            "rightsConstraints": {
                "geography": ["US", "CA"], "usageChannelsAllowed": ["web", "email", "linkedin"],
                "regulatoryNotes": "No client-specific regulatory carve-outs on file for US",
            },
        },
        "UK": {
            "market": "UK",
            "approvedRepositories": [
                {"contentProfile": "creativeAsset", "repositoryId": "bmc-dam-global", "priority": 1, "included": True},
                {"contentProfile": "publishedWebContent", "repositoryId": "eycom-sites", "priority": 1, "included": True},
                {"contentProfile": "peopleOfficeProfile", "repositoryId": "eycom-people-profiles", "priority": 2, "included": True},
                {"contentProfile": "brandGuidelineReference", "repositoryId": "branding-zone-us", "priority": 2, "included": True},
            ],
            "rightsConstraints": {"geography": ["UK"], "usageChannelsAllowed": ["web", "email", "linkedin"],
                                    "regulatoryNotes": ""},
        },
    }

    _INTENT_PROFILE_BOOST: dict[str, dict[str, float]] = {
        "assetReuse":            {"creativeAsset": 1.00, "publishedWebContent": 0.40, "peopleOfficeProfile": 0.05, "brandGuidelineReference": 0.20},
        "publishedContentCheck": {"creativeAsset": 0.30, "publishedWebContent": 1.00, "peopleOfficeProfile": 0.10, "brandGuidelineReference": 0.15},
        "brandGuidelineLookup":  {"creativeAsset": 0.25, "publishedWebContent": 0.20, "peopleOfficeProfile": 0.05, "brandGuidelineReference": 1.00},
        "templateRequest":       {"creativeAsset": 0.10, "publishedWebContent": 0.10, "peopleOfficeProfile": 0.05, "brandGuidelineReference": 1.00},
        "peopleProfileLookup":   {"creativeAsset": 0.05, "publishedWebContent": 0.20, "peopleOfficeProfile": 1.00, "brandGuidelineReference": 0.05},
        "unspecified":           {"creativeAsset": 0.70, "publishedWebContent": 0.70, "peopleOfficeProfile": 0.50, "brandGuidelineReference": 0.60},
    }

    _TEMPLATE_LINK_BOOST = {
        "appliesToProfile": "brandGuidelineReference", "activeForIntent": "templateRequest",
        "boostIfHasTemplateLink": 1.00, "boostIfNoTemplateLink": 0.35, "penaltyIfTemplateLinkNotCurrent": 0.20,
    }

    _SOURCE_DATA_QUALITY_WEIGHT = {"AdobeDAM": 1.00, "EYcom": 0.90, "ContentFragment": 0.90, "SharePoint": 0.75, "Brightcove": 0.00}

    _METADATA_COMPLETENESS = {
        "byContentProfile": {
            "creativeAsset": {"requiredFields": ["title", "description", "approvalStatus", "lifecycleStatus", "licenseType"], "penaltyPerMissing": 0.15},
            "publishedWebContent": {"requiredFields": ["title", "description", "publicationStatus", "liveURL"], "penaltyPerMissing": 0.15},
            "peopleOfficeProfile": {"requiredFields": ["firstName", "lastName", "jobTitle", "officeLocation"], "penaltyPerMissing": 0.20},
            "brandGuidelineReference": {
                "requiredFields": ["title", "description", "pageCategory"],
                "conditionalRequiredFields": {"whenHasTemplateLink": ["templateFileUrl", "templateVersion"]},
                "penaltyPerMissing": 0.10, "penaltyPerMissingConditional": 0.15,
            },
        },
        "floorScore": 0.20, "flagAsLowConfidenceBelow": 0.50,
    }

    _AUDIENCE_MARKET_MATCH = {
        "exactMatchWeight": 1.00, "partialMatchWeight": 0.55, "noMatchWeight": 0.10,
        "dimensions": ["audience", "market", "channel", "campaign"], "appliesToProfiles": ["creativeAsset"],
    }

    def get_taxonomy_domain(self, domain: str) -> dict[str, Any]:
        return self._TAXONOMY_DOMAINS.get(domain, {"domain": domain, "values": []})

    def get_taxonomy_options(self, domain: str) -> list[str]:
        return [v["value"] for v in self.get_taxonomy_domain(domain).get("values", [])]

    def get_query_intent_detection_cues(self) -> dict[str, list[str]]:
        return self._TAXONOMY_DOMAINS["queryIntent"].get("detectionCues", {})

    def get_content_profile(self, content_profile: str) -> dict[str, Any]:
        return self._CONTENT_PROFILES.get(content_profile, {})

    def get_all_content_profiles(self) -> list[dict[str, Any]]:
        return list(self._CONTENT_PROFILES.values())

    def get_governance_rule(self, market: Optional[str]) -> dict[str, Any]:
        return self._GOVERNANCE_RULES.get(market or "US", self._GOVERNANCE_RULES["US"])

    def get_intent_profile_boost(self) -> dict[str, dict[str, float]]:
        return self._INTENT_PROFILE_BOOST

    def get_template_link_boost(self) -> dict[str, Any]:
        return self._TEMPLATE_LINK_BOOST

    def get_source_data_quality_weights(self) -> dict[str, float]:
        return self._SOURCE_DATA_QUALITY_WEIGHT

    def get_metadata_completeness_thresholds(self) -> dict[str, Any]:
        return self._METADATA_COMPLETENESS

    def get_audience_market_match_signal(self) -> dict[str, Any]:
        return self._AUDIENCE_MARKET_MATCH

    def get_repository_scope(self, market: Optional[str]) -> list[str]:
        rule = self.get_governance_rule(market)
        return [r["repositoryId"] for r in rule.get("approvedRepositories", []) if r.get("included")]

    def get_approved_approval_statuses(self) -> list[str]:
        return ["approved"]

    def get_business_ranking_weights(self) -> dict[str, float]:
        return {"approved_boost": 1.0}


def get_taxonomy_store(use_mock: bool = True, **real_client_kwargs) -> TaxonomyStore:
    if use_mock:
        return MockTaxonomyStore()
    return RealCosmosTaxonomyStore(**real_client_kwargs)

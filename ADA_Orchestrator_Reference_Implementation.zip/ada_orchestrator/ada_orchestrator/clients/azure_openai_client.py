"""
Thin wrapper around Azure OpenAI chat completions with forced tool-calling,
plus embeddings. Production implementation uses the `openai` SDK's
AzureOpenAI client; a deterministic mock is provided so the orchestrator can
run and be unit-tested without live credentials.

Swap `get_llm_client()`'s return value to `RealAzureOpenAIClient` in
production (see config.USE_MOCK_CLIENTS).
"""

from __future__ import annotations

import hashlib
from typing import Any


class LLMClient:
    """Interface every LLM client (real or mock) implements."""

    def call_tool(
        self,
        system_prompt: str,
        user_message: str,
        tool_schema: dict[str, Any],
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Call the chat model with a forced tool call and return the parsed
        function-call arguments as a dict."""
        raise NotImplementedError

    def embed(self, text: str) -> list[float]:
        raise NotImplementedError

    def set_active_thread(self, thread_id: str | None) -> None:
        """Bind subsequent call_tool() calls to a specific conversation
        thread. No-op for clients that don't have a notion of a server-side
        thread (e.g. plain chat-completions clients); meaningful for
        Foundry-backed clients, where every step in one user turn should run
        against the same Foundry Thread for continuity and tracing."""
        return None


class RealAzureOpenAIClient(LLMClient):
    """Production client. Requires `openai>=1.40` and Azure OpenAI credentials."""

    def __init__(self, endpoint: str, api_key: str, chat_deployment: str,
                 embedding_deployment: str, api_version: str):
        from openai import AzureOpenAI  # imported lazily so mock mode has no hard dependency

        self._client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=api_version,
        )
        self._chat_deployment = chat_deployment
        self._embedding_deployment = embedding_deployment

    def call_tool(self, system_prompt, user_message, tool_schema, context=None) -> dict[str, Any]:
        import json

        messages = [{"role": "system", "content": system_prompt}]
        if context:
            messages.append({"role": "system", "content": f"Conversation context: {json.dumps(context)}"})
        messages.append({"role": "user", "content": user_message})

        forced_name = tool_schema["function"]["name"]
        response = self._client.chat.completions.create(
            model=self._chat_deployment,
            messages=messages,
            tools=[tool_schema],
            tool_choice={"type": "function", "function": {"name": forced_name}},
            temperature=0,
        )
        tool_call = response.choices[0].message.tool_calls[0]
        return json.loads(tool_call.function.arguments)

    def embed(self, text: str) -> list[float]:
        resp = self._client.embeddings.create(model=self._embedding_deployment, input=text)
        return resp.data[0].embedding


class MockAzureOpenAIClient(LLMClient):
    """
    Deterministic, dependency-free mock used for local dev, unit tests, and
    the bundled `example_run.py` demo. It performs simple keyword extraction
    instead of real LLM reasoning -- good enough to exercise every branch of
    the orchestrator (missing slots, guided questions incl. intent
    disambiguation, and grounded ranking rationale) without a live endpoint.
    Source/content-profile weighting is NOT mocked here because it is not an
    LLM call at all -- see steps/step4b_source_priority.py, which reads
    directly from TaxonomyStore.
    """

    _ROLE_KEYWORDS = {
        "designer": "Designer", "editor": "Picture Editor", "marketer": "Marketer",
        "picture editor": "Picture Editor", "partner": "Partner", "leadership": "Leadership",
    }
    _FORMAT_KEYWORDS = {
        "image": "image", "picture": "image", "photo": "image", "video": "video",
        "document": "document", "doc": "document", "template": "template", "pdf": "document",
    }
    _DEST_KEYWORDS = {
        "webpage": "ey.com webpage", "website": "ey.com webpage", "ey.com": "ey.com webpage",
        "linkedin": "LinkedIn post", "deck": "client presentation", "presentation": "client presentation",
        "email": "email", "social": "social post",
    }

    def call_tool(self, system_prompt, user_message, tool_schema, context=None) -> dict[str, Any]:
        name = tool_schema["function"]["name"]
        text = user_message.lower()
        ctx = context or {}

        if name == "extract_intent":
            return self._extract_intent(text, ctx)
        if name == "ask_clarifying_question":
            return self._ask_clarifying_question(ctx)
        if name == "write_rationale":
            return self._write_rationale(ctx)
        if name == "write_confirmation_prompt":
            return self._write_confirmation_prompt(ctx)
        raise ValueError(f"MockAzureOpenAIClient: no handler for tool '{name}'")

    def embed(self, text: str) -> list[float]:
        # Deterministic pseudo-embedding via hashing -- fine for the mock's
        # own cosine-similarity comparisons, meaningless outside this mock.
        h = hashlib.sha256(text.lower().strip().encode()).digest()
        return [b / 255.0 for b in h[:16]]

    # -- individual tool mocks -------------------------------------------------

    def _slot(self, value, confidence):
        return {"value": value, "confidence": confidence} if value else {"value": None, "confidence": "none"}

    def _extract_intent(self, text: str, ctx: dict[str, Any]) -> dict[str, Any]:
        role = next((v for k, v in self._ROLE_KEYWORDS.items() if k in text), None)
        fmt = next((v for k, v in self._FORMAT_KEYWORDS.items() if k in text), None)
        dest = next((v for k, v in self._DEST_KEYWORDS.items() if k in text), None)

        # crude "subject" extraction: text between "shows/about/for" and end/next clause
        subject = None
        for marker in ["shows ", "about ", "represents ", "on ", "for a cfo", "resilience", "transformation"]:
            if marker in text:
                subject = marker.strip() if marker.strip() not in ("for a cfo",) else "CFO-related content"
                if marker == "resilience":
                    subject = "resilience/risk management"
                elif marker == "transformation":
                    subject = "AI transformation"
                break

        market = "UK" if " uk " in f" {text} " else ("US" if " us " in f" {text} " else None)
        audience = "CFO" if "cfo" in text else ("CIO" if "cio" in text else None)

        person_query = None
        for marker in ["who is", "bio for", "contact for", "profile for", "office location of"]:
            if marker in text:
                person_query = text.split(marker, 1)[1].strip().rstrip("?.")
                break

        # -- query_intent classification, grounded in the detection cues
        # Cosmos DB provided in context (taxonomy-classification container),
        # not in a hardcoded category list -- mirrors what a real LLM call
        # is instructed to do (see QUERY_UNDERSTANDING_SYSTEM_PROMPT).
        cues: dict[str, list[str]] = ctx.get("query_intent_detection_cues", {})
        valid_intents: list[str] = ctx.get("valid_query_intents", [])
        fallback = ctx.get("query_intent_fallback_value", "unspecified")

        hits: dict[str, int] = {}
        for intent, phrases in cues.items():
            hits[intent] = sum(1 for p in phrases if p.lower() in text)

        query_intent, confidence = fallback, "none"
        tied_candidates: list[str] = []
        if hits:
            sorted_hits = sorted(hits.items(), key=lambda kv: kv[1], reverse=True)
            best_intent, best_count = sorted_hits[0]
            second_intent, second_count = sorted_hits[1] if len(sorted_hits) > 1 else (None, 0)
            if best_count > 0:
                query_intent = best_intent
                if best_count >= 2 and best_count > second_count:
                    confidence = "high"
                elif best_count > second_count:
                    confidence = "medium"
                else:
                    confidence = "low"  # tie between two intents -- genuinely ambiguous
                    if second_intent:
                        tied_candidates = [best_intent, second_intent]

        if valid_intents and query_intent not in valid_intents:
            query_intent, confidence, tied_candidates = fallback, "none", []

        result = {
            "user_role": self._slot(role, "high" if role else "none"),
            "asset_format": self._slot(fmt, "high" if fmt else "none"),
            "asset_subject": self._slot(subject, "medium" if subject else "none"),
            "destination_use": self._slot(dest, "high" if dest else "none"),
            "audience": self._slot(audience, "high" if audience else "none"),
            "market": self._slot(market, "high" if market else "none"),
            "campaign": self._slot(None, "none"),
            "service_line": self._slot(None, "none"),
            "language": self._slot(None, "none"),
            "person_query": self._slot(person_query, "high" if person_query else "none"),
            "query_intent": self._slot(query_intent, confidence),
        }
        if tied_candidates:
            result["query_intent_candidates"] = tied_candidates
        return result

    def _ask_clarifying_question(self, ctx: dict[str, Any]) -> dict[str, Any]:
        situation = ctx.get("situation", "missing_slot")

        if situation == "ambiguous_intent":
            candidates = ctx.get("candidate_intents", [])
            phrasing_by_pair = {
                frozenset(["templateRequest", "brandGuidelineLookup"]):
                    "Are you looking for a ready-to-use template file, or a brand guideline/rule to follow?",
                frozenset(["assetReuse", "publishedContentCheck"]):
                    "Are you looking to reuse a campaign asset, or checking whether something is already published?",
            }
            question = phrasing_by_pair.get(
                frozenset(candidates),
                "Just to make sure I search the right place -- are you looking for a finished asset, a template, or a guideline?",
            )
            return {"target_slot": "query_intent", "question_text": question, "options_shown": candidates}

        slot = ctx.get("target_slot", "asset_subject")
        options = ctx.get("options", [])
        phrasing = {
            "user_role": "Who is this for -- are you a designer, marketer, or client-facing team member?",
            "asset_format": "What format do you need -- an image, a document, or a video?",
            "asset_subject": "What's the topic or subject the asset should cover?",
            "destination_use": "Where will this be used -- a webpage, a deck, or a social post?",
            "person_query": "Who are you trying to find -- a name, role, or office?",
        }
        return {
            "target_slot": slot,
            "question_text": phrasing.get(slot, f"Can you tell me more about {slot.replace('_', ' ')}?"),
            "options_shown": options,
        }

    def _write_rationale(self, ctx: dict[str, Any]) -> dict[str, Any]:
        asset = ctx["asset"]
        assumed = ctx.get("assumed_slots", [])
        parts = []
        if asset.get("topic"):
            parts.append(f"matches the requested topic ({', '.join(asset['topic'])})")
        if asset.get("approval_status"):
            parts.append(f"approval status is {asset['approval_status']}")
        if asset.get("title_source") == "ai_generated":
            parts.append("title/description were AI-generated at ingestion and are pending content-owner review")
        if asset.get("has_template_link"):
            parts.append("a ready-to-use template file is attached")
        text = "Recommended because it " + "; ".join(parts) + "." if parts else "Recommended based on available metadata match."
        cites_assumption = False
        if assumed:
            text += f" Note: {', '.join(assumed)} was not specified, so this reflects a broad/default match rather than a stated preference."
            cites_assumption = True
        return {"rationale_text": text, "cites_assumption": cites_assumption}

    def _write_confirmation_prompt(self, ctx: dict[str, Any]) -> dict[str, Any]:
        n = ctx.get("result_count", 0)
        assumed = ctx.get("assumptions_made", False)
        if assumed:
            text = (f"I found {n} results, but assumed some details you didn't specify -- "
                     "let me know if these look right or if you'd like to narrow by market, audience, or channel.")
        else:
            text = f"Here are {n} results matching what you described -- do these work, or should I narrow further?"
        return {"prompt_text": text}


def get_llm_client(use_mock: bool = True, **real_client_kwargs) -> LLMClient:
    if use_mock:
        return MockAzureOpenAIClient()
    return RealAzureOpenAIClient(**real_client_kwargs)

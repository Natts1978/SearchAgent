"""
Semantic query cache -- Step 4c (Solution Approach Section 2.3.2). Azure
Cache for Redis Enterprise (vector similarity) in production; a tiny
in-process cosine-similarity cache for local dev/demo.
"""

from __future__ import annotations

import math
import time
from typing import Any, Optional

from ada_orchestrator import config


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class SemanticCache:
    def get(self, query_vector: list[float]) -> Optional[dict[str, Any]]:
        raise NotImplementedError

    def set(self, query_vector: list[float], governed_result: dict[str, Any]) -> None:
        raise NotImplementedError


class RealRedisSemanticCache(SemanticCache):
    """Production client. Requires `redis` with RediSearch/vector support enabled."""

    def __init__(self, connection_string: str, ttl_seconds: int, similarity_threshold: float):
        import redis

        self._client = redis.from_url(connection_string)
        self._ttl = ttl_seconds
        self._threshold = similarity_threshold

    def get(self, query_vector: list[float]) -> Optional[dict[str, Any]]:
        # Production: FT.SEARCH against a RediSearch vector index with KNN,
        # then verify the returned similarity score against self._threshold.
        raise NotImplementedError("Wire to RediSearch vector KNN query in production.")

    def set(self, query_vector: list[float], governed_result: dict[str, Any]) -> None:
        raise NotImplementedError("Wire to Redis HSET + vector field in production.")


class MockSemanticCache(SemanticCache):
    def __init__(self, ttl_seconds: int = None, similarity_threshold: float = None):
        self._ttl = ttl_seconds or config.SEMANTIC_CACHE_TTL_SECONDS
        self._threshold = similarity_threshold or config.SEMANTIC_CACHE_SIMILARITY_THRESHOLD
        self._entries: list[tuple[list[float], dict[str, Any], float]] = []  # (vector, result, expires_at)

    def get(self, query_vector: list[float]) -> Optional[dict[str, Any]]:
        now = time.time()
        self._entries = [e for e in self._entries if e[2] > now]  # evict expired
        for vec, result, _ in self._entries:
            if _cosine(vec, query_vector) >= self._threshold:
                return result
        return None

    def set(self, query_vector: list[float], governed_result: dict[str, Any]) -> None:
        self._entries.append((query_vector, governed_result, time.time() + self._ttl))


def get_semantic_cache(use_mock: bool = True, **real_client_kwargs) -> SemanticCache:
    if use_mock:
        return MockSemanticCache()
    return RealRedisSemanticCache(**real_client_kwargs)

"""
Telemetry & Feedback Capture -- Step 12. Production writes to Log Analytics /
Application Insights (via the OpenTelemetry SDK) and Microsoft Purview for
audit. The mock just appends to an in-memory list so `example_run.py` can
print a readable trace.
"""

from __future__ import annotations

from typing import Any


class TelemetryClient:
    def log_event(self, event_name: str, correlation_id: str, payload: dict[str, Any]) -> None:
        raise NotImplementedError


class RealAppInsightsTelemetryClient(TelemetryClient):
    def __init__(self, connection_string: str):
        from opentelemetry import trace  # production: configure Azure Monitor exporter here

        self._tracer = trace.get_tracer("ada.orchestrator")

    def log_event(self, event_name: str, correlation_id: str, payload: dict[str, Any]) -> None:
        with self._tracer.start_as_current_span(event_name) as span:
            span.set_attribute("correlation_id", correlation_id)
            for k, v in payload.items():
                span.set_attribute(k, str(v))


class MockTelemetryClient(TelemetryClient):
    def __init__(self):
        self.events: list[dict[str, Any]] = []

    def log_event(self, event_name: str, correlation_id: str, payload: dict[str, Any]) -> None:
        self.events.append({"event": event_name, "correlation_id": correlation_id, **payload})


def get_telemetry_client(use_mock: bool = True, **real_client_kwargs) -> TelemetryClient:
    if use_mock:
        return MockTelemetryClient()
    return RealAppInsightsTelemetryClient(**real_client_kwargs)

"""
Conversation/session persistence -- Step 3a. In production this is a Cosmos
DB container used as Foundry Agent Service's Bring-Your-Own-Storage target
for Threads (Solution Approach Section 2.3.3), holding the
(channel, external_conversation_id) -> thread_id mapping plus the SlotState
and prior-results needed for continuity and the guided-question round cap.

The mock below is a plain in-process dict -- fine for local dev/demo, not for
multi-instance production (which is exactly why the real Cosmos-backed
version exists).
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Optional

from ada_orchestrator.models import ThreadState

if TYPE_CHECKING:
    from ada_orchestrator.clients.foundry_agent_client import FoundryThreadResolver


class ThreadStore:
    def get_or_create(self, channel: str, external_conversation_id: str, user_id: str) -> ThreadState:
        raise NotImplementedError

    def save(self, thread: ThreadState) -> None:
        raise NotImplementedError


class RealCosmosThreadStore(ThreadStore):
    """
    Production client. Requires `azure-cosmos`.

    Per Solution Approach Section 2.3.3, this container holds the
    (channel, external_conversation_id) -> thread mapping in the SAME Cosmos
    DB account as the CIL Metadata Store (a dedicated container, kept
    separate from the governance container per Section 2.3.1's
    business/engineering config separation).

    When `foundry_resolver` is provided, `thread_id` here IS the real Foundry
    Agent Service thread id (created via FoundryThreadResolver.create_thread())
    -- this is the Bring-Your-Own-Storage Thread the architecture calls for,
    not a locally-generated placeholder. When no resolver is provided (e.g.
    running with RealAzureOpenAIClient instead of the Foundry Coded Agent
    path), a local uuid is used instead, and ThreadState.foundry_thread_id
    stays None.
    """

    def __init__(self, endpoint: str, key: str, database: str, container: str,
                 foundry_resolver: Optional["FoundryThreadResolver"] = None):
        from azure.cosmos import CosmosClient

        self._container = (
            CosmosClient(endpoint, key).get_database_client(database).get_container_client(container)
        )
        self._foundry_resolver = foundry_resolver

    def get_or_create(self, channel: str, external_conversation_id: str, user_id: str) -> ThreadState:
        lookup_key = f"{channel}:{external_conversation_id}"
        try:
            item = self._container.read_item(item=lookup_key, partition_key=lookup_key)
            return _item_to_thread(item)
        except Exception:  # azure.cosmos.exceptions.CosmosResourceNotFoundError in production
            if self._foundry_resolver is not None:
                foundry_thread_id = self._foundry_resolver.create_thread()
                thread_id = foundry_thread_id
            else:
                foundry_thread_id = None
                thread_id = str(uuid.uuid4())
            thread = ThreadState(
                thread_id=thread_id, channel=channel, external_conversation_id=external_conversation_id,
                user_id=user_id, foundry_thread_id=foundry_thread_id,
            )
            self.save(thread)
            return thread

    def save(self, thread: ThreadState) -> None:
        lookup_key = f"{thread.channel}:{thread.external_conversation_id}"
        self._container.upsert_item(_thread_to_item(thread, lookup_key))


def _thread_to_item(thread: ThreadState, lookup_key: str) -> dict:
    return {
        "id": lookup_key,
        "thread_id": thread.thread_id,
        "foundry_thread_id": thread.foundry_thread_id,
        "channel": thread.channel,
        "external_conversation_id": thread.external_conversation_id,
        "user_id": thread.user_id,
        "market": thread.market,
        "slot_state": thread.slot_state.as_dict(),
        "round_count": thread.slot_state.round_count,
        "prior_results": thread.prior_results,
        "created_at": thread.created_at,
        "updated_at": thread.updated_at,
    }


def _item_to_thread(item: dict) -> ThreadState:
    from ada_orchestrator.models import SlotState, SlotValue

    slot_state = SlotState()
    for name, payload in item.get("slot_state", {}).items():
        if name in slot_state.slots:
            slot_state.slots[name] = SlotValue(**payload)
    slot_state.round_count = item.get("round_count", 0)

    return ThreadState(
        thread_id=item["thread_id"], channel=item["channel"],
        external_conversation_id=item["external_conversation_id"], user_id=item["user_id"],
        foundry_thread_id=item.get("foundry_thread_id"),
        market=item.get("market"), slot_state=slot_state,
        prior_results=item.get("prior_results", []),
        created_at=item.get("created_at"), updated_at=item.get("updated_at"),
    )


class MockThreadStore(ThreadStore):
    def __init__(self):
        self._store: dict[str, ThreadState] = {}

    def get_or_create(self, channel: str, external_conversation_id: str, user_id: str) -> ThreadState:
        key = f"{channel}:{external_conversation_id}"
        if key not in self._store:
            self._store[key] = ThreadState(
                thread_id=str(uuid.uuid4()), channel=channel,
                external_conversation_id=external_conversation_id, user_id=user_id,
            )
        return self._store[key]

    def save(self, thread: ThreadState) -> None:
        key = f"{thread.channel}:{thread.external_conversation_id}"
        thread.touch()
        self._store[key] = thread


def get_thread_store(use_mock: bool = True, foundry_resolver: Optional["FoundryThreadResolver"] = None,
                      **real_client_kwargs) -> ThreadStore:
    if use_mock:
        return MockThreadStore()
    return RealCosmosThreadStore(foundry_resolver=foundry_resolver, **real_client_kwargs)

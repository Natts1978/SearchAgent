"""
Tool (function-calling) schemas for every LLM call site in the orchestrator.

Each schema is passed to the Azure OpenAI `tools=[...]` parameter alongside
the matching system prompt from `prompts.py`, with `tool_choice` forced to the
named function so the model cannot reply with free text instead of the
structured shape the orchestrator code expects.

Naming convention: `<STEP>_TOOL` mirrors the prompt name in prompts.py, and
`<STEP>_TOOL["function"]["name"]` is the function name the model must call.
"""

_SLOT_OBJECT = {
    "type": "object",
    "properties": {
        "value": {"type": ["string", "null"]},
        "confidence": {"type": "string", "enum": ["high", "medium", "low", "none"]},
    },
    "required": ["value", "confidence"],
}

EXTRACT_INTENT_TOOL = {
    "type": "function",
    "function": {
        "name": "extract_intent",
        "description": (
            "Record extracted search-intent slots AND the classified query_intent "
            "from the user's message. Only fill a slot if it was actually stated "
            "or clearly implied; only classify query_intent against the cue set "
            "you were given in context, never invent a category."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "user_role": _SLOT_OBJECT,
                "asset_format": _SLOT_OBJECT,
                "asset_subject": _SLOT_OBJECT,
                "destination_use": _SLOT_OBJECT,
                "audience": _SLOT_OBJECT,
                "market": _SLOT_OBJECT,
                "campaign": _SLOT_OBJECT,
                "service_line": _SLOT_OBJECT,
                "language": _SLOT_OBJECT,
                "person_query": _SLOT_OBJECT,
                "query_intent": _SLOT_OBJECT,
            },
            "required": ["user_role", "asset_format", "asset_subject", "destination_use", "query_intent"],
        },
    },
}

ASK_CLARIFYING_QUESTION_TOOL = {
    "type": "function",
    "function": {
        "name": "ask_clarifying_question",
        "description": (
            "Ask exactly one clarifying question -- either targeting the highest-priority "
            "missing slot, or disambiguating the classified query intent when it's ambiguous "
            "(pass target_slot='query_intent' in that case)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "target_slot": {"type": "string", "description": "The single slot (or 'query_intent') this question targets."},
                "question_text": {"type": "string"},
                "options_shown": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Taxonomy option values (or plain-language intent labels) referenced in the question, if any. Must be a subset of what was provided -- never invented.",
                },
            },
            "required": ["target_slot", "question_text"],
        },
    },
}

SET_SOURCE_WEIGHTS_TOOL = None  # REMOVED -- source/content-profile prioritization is now a
                                 # deterministic Cosmos DB matrix lookup (steps/step4b_source_priority.py),
                                 # not an LLM decision. Kept as a named placeholder (rather than
                                 # deleting the symbol outright) so any external caller importing
                                 # this name fails loudly/obviously instead of silently on an
                                 # ImportError from a renamed module.

WRITE_RATIONALE_TOOL = {
    "type": "function",
    "function": {
        "name": "write_rationale",
        "description": "Write a grounded, one-to-two sentence 'why recommended' rationale for one candidate asset.",
        "parameters": {
            "type": "object",
            "properties": {
                "rationale_text": {"type": "string"},
                "cites_assumption": {
                    "type": "boolean",
                    "description": "True if the rationale explicitly flags that an assumed (not stated) slot influenced this result.",
                },
            },
            "required": ["rationale_text", "cites_assumption"],
        },
    },
}

WRITE_CONFIRMATION_PROMPT_TOOL = {
    "type": "function",
    "function": {
        "name": "write_confirmation_prompt",
        "description": "Write the post-results confirm/refine prompt shown to the user.",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt_text": {"type": "string"},
            },
            "required": ["prompt_text"],
        },
    },
}

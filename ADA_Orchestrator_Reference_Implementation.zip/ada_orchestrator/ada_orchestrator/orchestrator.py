"""
ADA Orchestrator -- Steps 3-9a of the confirmed user request flow, plus the
telemetry write at the end (Step 12). Steps 1-2 (user intent, channel submit)
and Step 10 (user action resolved at source) happen outside this module, in
the channel connector and the source systems respectively.

Entry point: `run_turn()`. Call this once per inbound user message,
regardless of channel (Teams, Copilot, custom portal) -- see the
channel-agnostic design principle in Solution Approach Section 2.3.4.

    Step 3a  -> resolve_thread                       (steps/step3a_conversation.py)
    Step 4   -> run_query_understanding              (steps/step4_query_understanding.py)
                -- extracts slots AND classifies query_intent, grounded in
                   Cosmos DB detectionCues (the "automatic" half of the
                   client's hybrid intent-gathering direction)
    Step 4a  -> run_guided_question_step   [NEW]      (steps/step4a_guided_questions.py)
                -- the "ask the user" half of the hybrid: disambiguates a
                   low-confidence query_intent OR fills a slot relevant to
                   whichever intent is currently known
    Step 4b  -> resolve_profile_boosts     [NEW, CORRECTED]  (steps/step4b_source_priority.py)
                -- deterministic Cosmos DB matrix lookup (trust-ranking-signals),
                   NOT an LLM call -- reads whatever query_intent Steps 4/4a
                   produced and returns the Cosmos-defined boost weights
    Step 4c  -> check_semantic_cache / write_...      (steps/step4c_semantic_cache.py)
    Step 5   -> build_governance_filter               (steps/step5_governance_filter.py)
    Step 6   -> run_hybrid_search                     (steps/step6_hybrid_search.py)
    Step 7   -> apply_live_permission_check           (steps/step7_live_permission_check.py)
    Step 8   -> rank_candidates / generate_result_cards (steps/step8_ranking_explanation.py)
                -- applies the Cosmos boost matrix (from 4b) plus
                   templateLinkBoost / sourceDataQualityWeight /
                   metadataCompletenessThresholds / audienceMarketMatch
    Step 9a  -> build_confirmation_prompt  [NEW]       (steps/step9a_confirmation.py)
    Step 12  -> telemetry.log_event                   (clients/telemetry_client.py)
"""

from __future__ import annotations

from dataclasses import dataclass

from ada_orchestrator import config
from ada_orchestrator.clients.azure_openai_client import LLMClient, get_llm_client
from ada_orchestrator.clients.search_client import SearchClient, get_search_client
from ada_orchestrator.clients.semantic_cache import SemanticCache, get_semantic_cache
from ada_orchestrator.clients.taxonomy_store import TaxonomyStore, get_taxonomy_store
from ada_orchestrator.clients.telemetry_client import TelemetryClient, get_telemetry_client
from ada_orchestrator.clients.thread_store import ThreadStore, get_thread_store
from ada_orchestrator.models import OrchestratorResponse, new_correlation_id
from ada_orchestrator.steps.step3a_conversation import resolve_thread
from ada_orchestrator.steps.step4_query_understanding import run_query_understanding
from ada_orchestrator.steps.step4a_guided_questions import run_guided_question_step
from ada_orchestrator.steps.step4c_semantic_cache import check_semantic_cache, write_semantic_cache
from ada_orchestrator.steps.step5_governance_filter import build_governance_filter
from ada_orchestrator.steps.step6_hybrid_search import run_hybrid_search
from ada_orchestrator.steps.step7_live_permission_check import (
    MockPermissionChecker, PermissionChecker, apply_live_permission_check,
)
from ada_orchestrator.steps.step8_ranking_explanation import generate_result_cards, rank_candidates
from ada_orchestrator.steps.step9a_confirmation import build_confirmation_prompt


@dataclass
class OrchestratorDependencies:
    """Everything the orchestrator needs. Build once (e.g. per Azure Functions
    host) and pass in, or use `build_dependencies()` for the default (mock or
    real, per config.USE_MOCK_CLIENTS) wiring."""

    llm: LLMClient
    search: SearchClient
    threads: ThreadStore
    cache: SemanticCache
    taxonomy: TaxonomyStore
    telemetry: TelemetryClient
    permission_checker: PermissionChecker


def build_dependencies(use_mock: bool = config.USE_MOCK_CLIENTS) -> OrchestratorDependencies:
    if use_mock:
        return OrchestratorDependencies(
            llm=get_llm_client(use_mock=True),
            search=get_search_client(use_mock=True),
            threads=get_thread_store(use_mock=True),
            cache=get_semantic_cache(use_mock=True),
            taxonomy=get_taxonomy_store(use_mock=True),
            telemetry=get_telemetry_client(use_mock=True),
            permission_checker=MockPermissionChecker(),
        )

    # --- Real dependency wiring ------------------------------------------
    # Two production paths for the LLM client, per config.USE_FOUNDRY_CODED_AGENT:
    #   False -> RealAzureOpenAIClient (direct chat completions, no Foundry)
    #   True  -> FoundryCodedAgentClient (orchestrator calls ADA's Foundry
    #            Coded Agent via Threads/Runs -- Section 2.3.3 / 4.1/4.2)
    # The Foundry path also swaps in a FoundryThreadResolver so Step 3a's
    # thread_id is a real Foundry Agent Service thread, not a local uuid.
    foundry_resolver = None
    if config.USE_FOUNDRY_CODED_AGENT:
        from ada_orchestrator.clients.foundry_agent_client import FoundryCodedAgentClient, FoundryThreadResolver

        foundry_resolver = FoundryThreadResolver(project_endpoint=config.AZURE_AI_PROJECT_ENDPOINT)
        llm_client: LLMClient = FoundryCodedAgentClient(
            project_endpoint=config.AZURE_AI_PROJECT_ENDPOINT,
            agent_id=config.FOUNDRY_CODED_AGENT_ID,
            poll_interval_seconds=config.FOUNDRY_RUN_POLL_INTERVAL_SECONDS,
            run_timeout_seconds=config.FOUNDRY_RUN_TIMEOUT_SECONDS,
        )
    else:
        llm_client = get_llm_client(
            use_mock=False, endpoint=config.AZURE_OPENAI_ENDPOINT, api_key=config.AZURE_OPENAI_API_KEY,
            chat_deployment=config.AZURE_OPENAI_CHAT_DEPLOYMENT,
            embedding_deployment=config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
            api_version=config.AZURE_OPENAI_API_VERSION,
        )

    return OrchestratorDependencies(
        llm=llm_client,
        search=get_search_client(
            use_mock=False, endpoint=config.AZURE_SEARCH_ENDPOINT, api_key=config.AZURE_SEARCH_API_KEY,
            index_name=config.AZURE_SEARCH_INDEX_NAME,
        ),
        threads=get_thread_store(
            use_mock=False, foundry_resolver=foundry_resolver,
            endpoint=config.COSMOS_ENDPOINT, key=config.COSMOS_KEY,
            database=config.COSMOS_DATABASE, container=config.COSMOS_THREAD_CONTAINER,
        ),
        cache=get_semantic_cache(
            use_mock=False, connection_string=config.REDIS_CONNECTION_STRING,
            ttl_seconds=config.SEMANTIC_CACHE_TTL_SECONDS,
            similarity_threshold=config.SEMANTIC_CACHE_SIMILARITY_THRESHOLD,
        ),
        taxonomy=get_taxonomy_store(
            use_mock=False, endpoint=config.COSMOS_ENDPOINT, key=config.COSMOS_KEY,
            database=config.COSMOS_DATABASE,
            content_profiles_container=config.COSMOS_CONTENT_PROFILES_CONTAINER,
            taxonomy_container=config.COSMOS_TAXONOMY_CONTAINER,
            signals_container=config.COSMOS_SIGNALS_CONTAINER,
            governance_container=config.COSMOS_GOVERNANCE_CONTAINER,
            field_mapping_container=config.COSMOS_FIELD_MAPPING_CONTAINER,
        ),
        telemetry=get_telemetry_client(use_mock=False, connection_string=""),
        permission_checker=MockPermissionChecker(),  # replace with RealGraphPermissionChecker in production
    )


def run_turn(
    deps: OrchestratorDependencies,
    channel: str,
    external_conversation_id: str,
    user_id: str,
    user_message: str,
    market: str | None = None,
) -> OrchestratorResponse:
    """Handle exactly one inbound user turn end-to-end. Safe to call again
    with the user's next message (e.g. an answer to a clarifying question,
    or a refine/confirm reply) -- state persists on the resolved thread."""

    correlation_id = new_correlation_id()

    # Step 3a
    thread = resolve_thread(deps.threads, channel, external_conversation_id, user_id)
    if market:
        thread.market = market
    deps.telemetry.log_event("request_received", correlation_id, {"thread_id": thread.thread_id, "message": user_message})

    # Bind every LLM call in this turn to the same Foundry Thread (no-op for
    # non-Foundry clients). This is what makes "prior turns, filters, results
    # already shown" (Section 2.3.3) actually hold across Steps 4/4a/4b/8/9a,
    # not just across Steps 3a's bookkeeping.
    deps.llm.set_active_thread(thread.foundry_thread_id)

    # If the PRIOR turn asked the user to disambiguate query_intent
    # directly, resolve their answer against only the offered candidates
    # first, and lock it in as "stated" -- before running the generic Step 4
    # extraction on the same message (which still runs, in case the user
    # volunteered other slot info in the same reply, but per models.py's
    # merge() guard it can no longer downgrade query_intent once stated).
    pending = thread.pending_clarifying_question
    if pending and pending.get("slot") == "query_intent" and pending.get("options"):
        from ada_orchestrator.steps.step4a_guided_questions import resolve_pending_intent_answer

        resolved = resolve_pending_intent_answer(deps.llm, deps.taxonomy, pending["options"], user_message)
        if resolved:
            thread.slot_state.set_query_intent_from_user_answer(resolved)

    # Step 4 -- extracts slots AND classifies query_intent (grounded in
    # Cosmos DB detection cues -- the automatic half of the hybrid design)
    run_query_understanding(deps.llm, deps.taxonomy, user_message, thread.slot_state)

    # Step 4a (NEW) -- guided question loop: disambiguates intent OR fills a
    # slot relevant to the currently-known intent (the "ask the user" half)
    should_ask, question = run_guided_question_step(deps.llm, deps.taxonomy, thread.slot_state)
    if should_ask:
        thread.pending_clarifying_question = {
            "slot": question.slot, "text": question.question_text, "options": question.options,
        }
        deps.threads.save(thread)
        deps.telemetry.log_event("clarifying_question_asked", correlation_id, {
            "thread_id": thread.thread_id, "slot": question.slot, "round": thread.slot_state.round_count,
        })
        return OrchestratorResponse(
            correlation_id=correlation_id, thread_id=thread.thread_id,
            status="clarifying_question", clarifying_question=question,
        )

    thread.pending_clarifying_question = None

    # Step 4c -- semantic cache check
    query_text = _build_query_text(thread.slot_state)
    query_vector, cached = check_semantic_cache(deps.llm, deps.cache, query_text)

    if cached is not None:
        candidates = cached["candidates"]
        deps.telemetry.log_event("semantic_cache_hit", correlation_id, {"thread_id": thread.thread_id})
    else:
        # Step 5 -- governance filter (approved repos per contentProfile,
        # eligibility gates, rights constraints -- all from Cosmos DB)
        governed_filter = build_governance_filter(deps.taxonomy, thread.slot_state, thread.market)
        # Step 6 -- retrieval only; no weighting applied here (see Step 8)
        candidates = run_hybrid_search(deps.llm, deps.search, query_text, query_vector, governed_filter)
        write_semantic_cache(deps.cache, query_vector, {"candidates": candidates})
        deps.telemetry.log_event("semantic_cache_miss", correlation_id, {"thread_id": thread.thread_id})

    # Step 7 -- live permission check (SharePoint only)
    candidates = apply_live_permission_check(deps.permission_checker, user_id, candidates)

    # Step 8 -- Cosmos-driven ranking (intentProfileBoost, templateLinkBoost,
    # sourceDataQualityWeight, completeness penalty, audienceMarketMatch) +
    # grounded explanation. Step 4b's boost resolution happens inside
    # rank_candidates() via resolve_profile_boosts(taxonomy, slot_state).
    candidates = rank_candidates(deps.taxonomy, candidates, thread.slot_state)
    result_cards = generate_result_cards(deps.llm, candidates, thread.slot_state)

    # Step 9a (NEW) -- confirmation checkpoint
    confirmation_prompt = build_confirmation_prompt(
        deps.llm, result_count=len(result_cards), assumptions_made=thread.slot_state.assumptions_made
    )

    thread.prior_results = [c.asset_id for c in candidates[:3]]
    thread.pending_confirmation = True
    deps.threads.save(thread)

    # Step 12
    deps.telemetry.log_event("results_returned", correlation_id, {
        "thread_id": thread.thread_id, "result_count": len(result_cards),
        "assumptions_made": thread.slot_state.assumptions_made,
        "query_intent": thread.slot_state.query_intent.value,
        "query_intent_source": thread.slot_state.query_intent.source,
    })

    return OrchestratorResponse(
        correlation_id=correlation_id, thread_id=thread.thread_id,
        status="results", result_cards=result_cards, confirmation_prompt=confirmation_prompt,
        assumptions_made=thread.slot_state.assumptions_made,
        debug={"slot_state": thread.slot_state.as_dict()},
    )


def _build_query_text(slot_state) -> str:
    if slot_state.query_intent.value == "peopleProfileLookup" and slot_state.slots["person_query"].value:
        return slot_state.slots["person_query"].value
    parts = []
    for slot_name in ("asset_subject", "asset_format", "destination_use", "audience", "market"):
        val = slot_state.slots[slot_name].value
        if val:
            parts.append(val)
    return " ".join(parts) if parts else "general approved content"

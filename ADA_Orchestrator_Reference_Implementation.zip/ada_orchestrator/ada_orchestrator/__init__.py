"""
ADA Orchestrator
=================
Reference implementation of the Asset Discovery Agent orchestration pipeline,
matching the confirmed architecture in:
  - CIL/ADA Solution Approach (v0.2) Section 2.2 / 2.3
  - ADA Detailed Documentation Section 6
  - Solution Approach Addendum v0.3 (guided intent collection, Steps 4a/4b/9a)

This package is channel-agnostic (Section 2.3.4 / 6.3 design principle): Teams,
Copilot, and any future channel are thin connectors that call `run_turn()`
below. No orchestration logic lives in a channel connector.

Clients (Azure OpenAI, Azure AI Search, Cosmos DB, Redis) are defined as thin
interfaces in `clients/` with a working in-memory mock implementation so this
package runs end-to-end without live Azure credentials. Swap the mocks for the
real SDK-backed classes in `clients/` to go to production -- the orchestration
logic in `orchestrator.py` and `steps/` does not change.
"""

__version__ = "0.1.0"

"""
Data models shared across orchestrator steps.

Slot names follow the W/X/Y/Z template from the business-user email, mapped
onto the confirmed ADA index schema (Solution Approach Addendum v0.3, Section 2.2):

    W -> user_role       (NEW field, not yet in the index schema -- see Addendum 1.2)
    X -> asset_format    (-> existing index field: assetType)
    Y -> asset_subject   (-> existing index field: topic)
    Z -> destination_use (-> existing index field: channel; may need a finer
                            "destination" sub-field per Addendum 2.2)

Plus the pre-existing ADA extraction fields (audience, market, campaign,
service_line, language) that were already part of Query Understanding
before the guided-intent addendum.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Slot schema
# ---------------------------------------------------------------------------

# Slots considered "critical" -- i.e. worth pausing search to ask about.
# NOTE: this list is a placeholder pending the client persona decision
# (Addendum Section 1.2 / 2.3). Treat as configuration, not a hardcoded fact.
CRITICAL_SLOTS: list[str] = ["user_role", "asset_format", "asset_subject", "destination_use"]

# All slots Query Understanding attempts to extract, critical or not.
# "person_query" is only relevant when query_intent == peopleProfileLookup
# (see INTENT_RELEVANT_SLOTS) -- a free-text name/role/office lookup, not
# part of the W/X/Y/Z asset-reuse template.
ALL_SLOTS: list[str] = CRITICAL_SLOTS + [
    "audience", "market", "campaign", "service_line", "language", "person_query",
]

# Round cap for the guided-question loop (Step 4a). Placeholder pending client
# decision -- see Addendum Section 2.3 and risk register (2.8).
DEFAULT_ROUND_CAP = 2

# The six queryIntent values, per CIL/ADA Cosmos DB Schema (Final Consolidated)
# Section 4.2, taxonomy-classification container, doc id "taxonomy::queryIntent".
# Classified by Step 4's Azure OpenAI GPT call ALONGSIDE entity extraction --
# not a separate LLM decision (see steps/step4b_source_priority.py, which is
# now a deterministic matrix lookup, not an LLM call).
QUERY_INTENTS: list[str] = [
    "assetReuse", "publishedContentCheck", "brandGuidelineLookup",
    "templateRequest", "peopleProfileLookup", "unspecified",
]

# Content profiles, per Cosmos schema Section 3. Each profile is anchored by
# a repository-content-profiles document and drives eligibility gates and
# ranking signals independent of which literal source system it lives in.
CONTENT_PROFILES: list[str] = [
    "creativeAsset", "publishedWebContent", "peopleOfficeProfile", "brandGuidelineReference",
]

# Static profile <-> primary source-system mapping, per Section 1/3 of the
# Cosmos schema doc. This is a 1:1 mapping today (Phase 1 sources); the
# schema itself does not assume 1:1 forever, so treat this dict as the
# current binding, not a structural guarantee.
PROFILE_TO_SOURCE_SYSTEM: dict[str, str] = {
    "creativeAsset": "AdobeDAM",
    "publishedWebContent": "EYcom",
    "peopleOfficeProfile": "ContentFragment",
    "brandGuidelineReference": "SharePoint",
}
SOURCE_SYSTEM_TO_PROFILE: dict[str, str] = {v: k for k, v in PROFILE_TO_SOURCE_SYSTEM.items()}

# Which of the generic W/X/Y/Z + audience/market/language slots are actually
# meaningful once a queryIntent is known. The W/X/Y/Z template (business-user
# email) was written with assetReuse in mind -- "asset_format" means nothing
# for a person search. Step 4a's guided-question loop uses this map to pick
# which slots are worth asking about for the CURRENTLY CLASSIFIED intent,
# instead of always asking about a fixed slot list regardless of intent.
#
# This is a hybrid point by design (per the client's explicit direction):
# queryIntent can come from automatic classification (Cosmos DB detectionCues,
# Step 4) OR from the user directly answering a guided question that named
# an intent-defining slot (Step 4a) -- either path lands in the same
# SlotState.query_intent field, and this table is what both paths read to
# decide what's still worth asking about.
#
# NOTE: this table itself is currently Python-side config, not Cosmos DB
# business-owned config. See the schema review notes for the recommendation
# to migrate it into repository-content-profiles once the client confirms it.
INTENT_RELEVANT_SLOTS: dict[str, list[str]] = {
    "assetReuse": ["user_role", "asset_format", "asset_subject", "destination_use", "audience", "market"],
    "publishedContentCheck": ["asset_subject", "market", "language"],
    "brandGuidelineLookup": ["asset_subject", "destination_use"],
    "templateRequest": ["asset_format", "destination_use"],
    "peopleProfileLookup": ["person_query"],
    "unspecified": CRITICAL_SLOTS,
}


@dataclass
class SlotValue:
    value: Optional[str] = None
    confidence: str = "none"       # "high" | "medium" | "low" | "none"
    source: str = "unset"          # "stated" | "assumed" | "unset"


@dataclass
class SlotState:
    """Accumulated slot-extraction state across one or more conversation turns.

    query_intent is tracked separately from the generic `slots` dict because
    it drives a matrix lookup (trust-ranking-signals::intentProfileBoost),
    not a search filter term, and because it can be set by TWO different
    paths that both need to merge into the same place:

      1. Automatic classification -- Step 4's LLM call classifies it
         alongside entity extraction, guided by Cosmos DB's detectionCues
         (taxonomy-classification container). source="inferred".
      2. Guided disambiguation -- Step 4a can ask the user directly when
         classification confidence is low (e.g. "template" vs "guideline"
         phrasing is genuinely ambiguous between templateRequest and
         brandGuidelineLookup). source="stated" once the user answers.

    Ranking (Step 8) always resolves weights from Cosmos DB's boost matrix
    keyed by whatever query_intent ends up in this field, regardless of
    which path set it -- the weighting is never itself decided by the LLM.
    """
    slots: dict[str, SlotValue] = field(default_factory=lambda: {s: SlotValue() for s in ALL_SLOTS})
    query_intent: SlotValue = field(default_factory=lambda: SlotValue(value="unspecified", confidence="none", source="unset"))
    query_intent_candidates: list[str] = field(default_factory=list)  # the actual tied/competing intents from the
                                                                       # last classification, when confidence was
                                                                       # low due to a genuine tie -- lets Step 4a's
                                                                       # disambiguation question name the real two
                                                                       # candidates instead of guessing a runner-up.
    round_count: int = 0
    assumptions_made: bool = False

    def merge(self, extracted: dict[str, dict[str, str]]) -> None:
        """Merge newly extracted slot values (including query_intent, if
        present in the payload) into existing state.

        Only overwrites a slot if the new extraction has equal or higher
        confidence than what is already held -- a later, vaguer turn should
        not erase a clearly-stated earlier value.
        """
        confidence_rank = {"high": 3, "medium": 2, "low": 1, "none": 0}

        if "query_intent" in extracted:
            if self.query_intent.source != "stated":
                # Once a user has directly stated the intent (via
                # set_query_intent_from_user_answer, e.g. answering Step 4a's
                # disambiguation question), a later generic re-extraction on
                # the same or a follow-up message must not silently downgrade
                # it back to "inferred" -- only another explicit stated
                # answer can change it from here.
                payload = extracted["query_intent"]
                new_intent = SlotValue(
                    value=payload.get("value") or "unspecified",
                    confidence=payload.get("confidence", "none"),
                    source="inferred" if payload.get("value") else self.query_intent.source,
                )
                if confidence_rank[new_intent.confidence] >= confidence_rank[self.query_intent.confidence]:
                    self.query_intent = new_intent
                    self.query_intent_candidates = extracted.get("query_intent_candidates", [])

        for name, payload in extracted.items():
            if name == "query_intent" or name not in self.slots:
                continue
            new_val = SlotValue(
                value=payload.get("value"),
                confidence=payload.get("confidence", "none"),
                source="stated" if payload.get("value") else "unset",
            )
            existing = self.slots[name]
            if confidence_rank[new_val.confidence] >= confidence_rank[existing.confidence] and new_val.value:
                self.slots[name] = new_val

    def set_query_intent_from_user_answer(self, intent_value: str) -> None:
        """Called when Step 4a's disambiguation question is answered
        directly (path 2 above) -- always wins over an inferred value,
        since the user is now stating it, not the classifier guessing it."""
        self.query_intent = SlotValue(value=intent_value, confidence="high", source="stated")

    def relevant_slots(self) -> list[str]:
        """Which slots matter for the CURRENTLY known query_intent. Falls
        back to the generic CRITICAL_SLOTS set when intent is still
        "unspecified" or too low-confidence to trust."""
        if self.query_intent.value in (None, "unspecified") or self.query_intent.confidence in ("none", "low"):
            return INTENT_RELEVANT_SLOTS["unspecified"]
        return INTENT_RELEVANT_SLOTS.get(self.query_intent.value, INTENT_RELEVANT_SLOTS["unspecified"])

    def intent_is_ambiguous(self, confidence_floor: str = "medium") -> bool:
        """True only when there IS a specific classified intent (not
        "unspecified"/unset) but it's held with less than `confidence_floor`
        confidence -- i.e. a genuine tie/uncertainty between real candidates
        (e.g. templateRequest vs brandGuidelineLookup both partially matched).

        Deliberately NOT true when query_intent is simply unset/"unspecified"
        with confidence "none" -- that's an absence of signal, not a
        disambiguation-worthy tie between named candidates, and should fall
        through to the generic relevant-slot question flow instead (see
        relevant_slots()'s "unspecified" fallback)."""
        if self.query_intent.value in (None, "unspecified"):
            return False
        rank = {"high": 3, "medium": 2, "low": 1, "none": 0}
        return rank[self.query_intent.confidence] < rank[confidence_floor]

    def missing_critical_slots(self) -> list[str]:
        """Intent-aware missing-slot check. Named `missing_critical_slots`
        for continuity with earlier callers; internally now reads
        `relevant_slots()` rather than the static CRITICAL_SLOTS list, per
        the hybrid design (Step 4a asks about what matters for the
        classified/stated intent, not a fixed slot list)."""
        return [
            s for s in self.relevant_slots()
            if s in self.slots and (not self.slots[s].value or self.slots[s].confidence in ("none", "low"))
        ]

    def mark_assumed(self, slot_names: list[str]) -> None:
        for name in slot_names:
            if name in self.slots and not self.slots[name].value:
                self.slots[name] = SlotValue(value="(unspecified)", confidence="none", source="assumed")
        self.assumptions_made = True

    def as_dict(self) -> dict[str, Any]:
        result = {
            name: {"value": sv.value, "confidence": sv.confidence, "source": sv.source}
            for name, sv in self.slots.items()
        }
        result["query_intent"] = {
            "value": self.query_intent.value, "confidence": self.query_intent.confidence,
            "source": self.query_intent.source, "candidates": self.query_intent_candidates,
        }
        return result


# ---------------------------------------------------------------------------
# Conversation / thread state (Step 3a)
# ---------------------------------------------------------------------------

@dataclass
class ThreadState:
    thread_id: str
    channel: str                       # "teams" | "copilot" | "custom_portal"
    external_conversation_id: str
    user_id: str
    foundry_thread_id: Optional[str] = None  # real Foundry Agent Service thread id, when Foundry is enabled
                                              # (Solution Approach Section 2.3.3). None in mock/non-Foundry mode.
    market: Optional[str] = None
    slot_state: SlotState = field(default_factory=SlotState)
    prior_results: list[dict[str, Any]] = field(default_factory=list)
    pending_clarifying_question: Optional[dict[str, Any]] = None
    pending_confirmation: bool = False
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def touch(self) -> None:
        self.updated_at = datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Search / results
# ---------------------------------------------------------------------------

class SourceSystem(str, Enum):
    ADOBE_DAM = "AdobeDAM"
    SHAREPOINT = "SharePoint"
    EY_COM = "EYcom"
    BRIGHTCOVE = "Brightcove"


@dataclass
class CandidateAsset:
    asset_id: str
    title: str
    title_source: str          # "source" | "ai_generated"
    description: str
    description_source: str    # "source" | "ai_generated"
    source_system: str
    source_url: str
    asset_type: str
    content_profile: str = ""  # creativeAsset | publishedWebContent | peopleOfficeProfile | brandGuidelineReference
                                # per repository-content-profiles (Cosmos schema Section 3) -- drives eligibility
                                # gates and ranking signals independent of the literal source_system.
    topic: list[str] = field(default_factory=list)
    channel: list[str] = field(default_factory=list)
    audience: list[str] = field(default_factory=list)
    market: list[str] = field(default_factory=list)
    approval_status: Optional[str] = None
    lifecycle_status: Optional[str] = None
    publication_status: Optional[str] = None  # publishedWebContent's eligibility gate field
    owner: Optional[str] = None
    restricted_flag: bool = False
    missing_metadata_fields: list[str] = field(default_factory=list)
    relevance_score: float = 0.0
    source_priority_weight: float = 1.0
    business_rank_score: float = 0.0
    low_confidence: bool = False  # set when combined score < flagAsLowConfidenceBelow (Cosmos schema Section 5.4)

    # -- eligibility-only fields (Cosmos schema Section 7): used for
    # governance filtering ONLY, never vectorized, never rendered as
    # description/title text (source-field-mapping's `eligibilityOnly: true`
    # flag). creativeAsset-specific.
    license_restriction: Optional[str] = None
    license_type: Optional[str] = None

    # -- brandGuidelineReference template-link fields (Cosmos schema Section 3.4)
    has_template_link: bool = False
    template_file_url: Optional[str] = None
    template_file_type: Optional[str] = None
    template_version: Optional[str] = None
    is_template_link_current: Optional[bool] = None

    # -- peopleOfficeProfile fields (Cosmos schema Section 3.3)
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    job_title: Optional[str] = None
    office_location: Optional[str] = None


@dataclass
class ResultCard:
    asset_id: str
    title: str
    title_flagged_ai_generated: bool
    description: str
    description_flagged_ai_generated: bool
    source_system: str
    source_url: str
    approval_status: Optional[str]
    lifecycle_status: Optional[str]
    owner: Optional[str]
    recommendation_rationale: str
    content_profile: str = ""
    low_confidence: bool = False
    # Rendered per Cosmos schema Section 8 Step 9: "Use template" action,
    # shown alongside the normal source link when has_template_link is true.
    use_template_url: Optional[str] = None
    counts_toward_reuse_kpi: bool = True  # False for peopleOfficeProfile results -- Section 3.3 note:
                                          # "a profile lookup is not a marketing-asset reuse event"


@dataclass
class ClarifyingQuestion:
    slot: str
    question_text: str
    options: list[str] = field(default_factory=list)  # sourced from taxonomy, never invented


@dataclass
class OrchestratorResponse:
    correlation_id: str
    thread_id: str
    status: str  # "clarifying_question" | "results" | "confirmation_pending" | "resolved"
    clarifying_question: Optional[ClarifyingQuestion] = None
    result_cards: list[ResultCard] = field(default_factory=list)
    confirmation_prompt: Optional[str] = None
    assumptions_made: bool = False
    debug: dict[str, Any] = field(default_factory=dict)


def new_correlation_id() -> str:
    return str(uuid.uuid4())

"""
Step 4c -- Semantic Query Cache Check (Solution Approach Section 2.3.2).

Renumbered from the original "4a" once Steps 4a/4b (guided intent) were
inserted, per Addendum Section 2.7. A cache hit still allows Step 7's live
SharePoint permission check to run -- caching is for the search+ranking
round-trip only, not for governance.
"""

from __future__ import annotations

from typing import Any, Optional

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.clients.semantic_cache import SemanticCache


def check_semantic_cache(llm: LLMClient, cache: SemanticCache, query_text: str) -> tuple[list[float], Optional[dict[str, Any]]]:
    query_vector = llm.embed(query_text)
    cached = cache.get(query_vector)
    return query_vector, cached


def write_semantic_cache(cache: SemanticCache, query_vector: list[float], governed_result: dict[str, Any]) -> None:
    cache.set(query_vector, governed_result)

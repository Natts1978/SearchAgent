"""
Step 3a -- Conversation Continuity Check.

Resolves (channel, external_conversation_id) -> a persistent thread via the
Cosmos-backed ThreadStore. Thin wrapper kept as its own step module so the
orchestrator reads in the same order as the architecture diagram.
"""

from __future__ import annotations

from ada_orchestrator.clients.thread_store import ThreadStore
from ada_orchestrator.models import ThreadState


def resolve_thread(store: ThreadStore, channel: str, external_conversation_id: str, user_id: str) -> ThreadState:
    return store.get_or_create(channel, external_conversation_id, user_id)

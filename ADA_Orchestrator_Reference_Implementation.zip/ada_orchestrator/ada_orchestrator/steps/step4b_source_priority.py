"""
Step 4b -- Source Prioritization Decision.

CORRECTED from the original design: this is now a deterministic Cosmos DB
matrix lookup, NOT an LLM call. Per the actual confirmed Cosmos schema
(CIL_ADA_CosmosDB_Schema_Final_Consolidated.docx, Section 5.1
intentProfileBoost + Section 8 Query Flow Integration table), the weighting
that prioritizes content profiles is a business-owned boost matrix keyed by
queryIntent -- it was never meant to be an LLM's free-form judgment call.

This is also where the client's explicit hybrid direction lands: it doesn't
matter whether `query_intent` in the SlotState was set by automatic
classification (Step 4, using Cosmos detectionCues) or by the user directly
answering a Step 4a disambiguation question -- this function reads whatever
ended up in SlotState.query_intent and looks up the SAME Cosmos-defined
weights either way. There is exactly one place weights come from, regardless
of which path produced the intent.

Output is provided at two granularities:
  - per-content-profile boosts (the schema's native unit -- used by Step 8's
    full combined-score formula, since each CandidateAsset carries its own
    content_profile)
  - per-source-system boosts (profile boost mapped through
    PROFILE_TO_SOURCE_SYSTEM -- used by Step 6's coarse hybrid-search
    weighting, since Azure AI Search filters/re-ranks on sourceSystem, not
    on a "contentProfile" field it doesn't index today)
"""

from __future__ import annotations

from ada_orchestrator.clients.taxonomy_store import TaxonomyStore
from ada_orchestrator.models import PROFILE_TO_SOURCE_SYSTEM, SlotState


def resolve_profile_boosts(taxonomy: TaxonomyStore, slot_state: SlotState) -> dict[str, float]:
    """queryIntent -> per-contentProfile boost, straight from
    trust-ranking-signals::intentProfileBoost. No LLM involved."""
    boost_matrix = taxonomy.get_intent_profile_boost()
    intent = slot_state.query_intent.value or "unspecified"
    return boost_matrix.get(intent, boost_matrix["unspecified"])


def resolve_source_weights(taxonomy: TaxonomyStore, slot_state: SlotState) -> dict[str, float]:
    """Convenience view of the same boosts, keyed by source system instead
    of content profile, for callers (Step 6) that weight by sourceSystem."""
    profile_boosts = resolve_profile_boosts(taxonomy, slot_state)
    return {
        PROFILE_TO_SOURCE_SYSTEM[profile]: weight
        for profile, weight in profile_boosts.items()
        if profile in PROFILE_TO_SOURCE_SYSTEM
    }

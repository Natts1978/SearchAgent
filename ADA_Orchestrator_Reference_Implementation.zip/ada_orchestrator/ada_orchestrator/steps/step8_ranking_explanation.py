"""
Step 8 -- Ranking + Explanation Logic | Grounding.

Implements the EXACT combined-score formula from the Cosmos DB schema
(CIL_ADA_CosmosDB_Schema_Final_Consolidated.docx, Section 5, "Step 8's
combined score"):

    score = AI Search relevance
          x intentProfileBoost[queryIntent][contentProfile]
          x templateLinkBoost                                  (brandGuidelineReference + templateRequest only)
          x sourceDataQualityWeight[sourceSystem]
          x (1 - completenessPenalty[contentProfile])
          x audienceMarketMatch tier                             (creativeAsset only)

    clamped to floorScore (0.20); flagged low_confidence below
    flagAsLowConfidenceBelow (0.50).

This REPLACES the earlier version, which only applied a generic
"approved_boost" multiplier and had no notion of content profile, template
link, data-quality weight, completeness penalty, or audience/market match --
none of which existed until the actual Cosmos schema was reviewed.
"""

from __future__ import annotations

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.clients.taxonomy_store import TaxonomyStore
from ada_orchestrator.models import CandidateAsset, ResultCard, SlotState
from ada_orchestrator.prompts import RANKING_EXPLANATION_SYSTEM_PROMPT
from ada_orchestrator.tools import WRITE_RATIONALE_TOOL
from ada_orchestrator.steps.step4b_source_priority import resolve_profile_boosts


def rank_candidates(taxonomy: TaxonomyStore, candidates: list[CandidateAsset], slot_state: SlotState) -> list[CandidateAsset]:
    profile_boosts = resolve_profile_boosts(taxonomy, slot_state)
    template_boost_signal = taxonomy.get_template_link_boost()
    source_quality = taxonomy.get_source_data_quality_weights()
    completeness = taxonomy.get_metadata_completeness_thresholds()
    audience_market_signal = taxonomy.get_audience_market_match_signal()

    query_intent = slot_state.query_intent.value or "unspecified"
    floor_score = completeness.get("floorScore", 0.0)
    low_confidence_below = completeness.get("flagAsLowConfidenceBelow", 0.0)

    for asset in candidates:
        score = asset.relevance_score

        # 1. intentProfileBoost
        profile_boost = profile_boosts.get(asset.content_profile, 1.0)
        score *= profile_boost
        asset.source_priority_weight = profile_boost  # kept for telemetry/debug visibility

        # 2. templateLinkBoost -- only for brandGuidelineReference + templateRequest
        if (asset.content_profile == template_boost_signal.get("appliesToProfile")
                and query_intent == template_boost_signal.get("activeForIntent")):
            if asset.has_template_link:
                score *= template_boost_signal.get("boostIfHasTemplateLink", 1.0)
                if asset.is_template_link_current is False:
                    score *= (1 - template_boost_signal.get("penaltyIfTemplateLinkNotCurrent", 0.0))
            else:
                score *= template_boost_signal.get("boostIfNoTemplateLink", 1.0)

        # 3. sourceDataQualityWeight
        score *= source_quality.get(asset.source_system, 1.0)

        # 4. metadataCompletenessThresholds -- penalty per missing required field
        profile_thresholds = completeness.get("byContentProfile", {}).get(asset.content_profile)
        if profile_thresholds:
            required = list(profile_thresholds.get("requiredFields", []))
            if asset.has_template_link:
                required += profile_thresholds.get("conditionalRequiredFields", {}).get("whenHasTemplateLink", [])
            missing_required = [f for f in required if _field_is_missing(asset, f)]
            penalty = len(missing_required) * profile_thresholds.get("penaltyPerMissing", 0.0)
            score *= max(0.0, 1 - penalty)

        # 5. audienceMarketMatch -- creativeAsset only
        if asset.content_profile in audience_market_signal.get("appliesToProfiles", []):
            score *= _audience_market_match_weight(asset, slot_state, audience_market_signal)

        score = max(score, floor_score)
        asset.business_rank_score = score
        asset.low_confidence = score < low_confidence_below

    candidates.sort(key=lambda c: c.business_rank_score, reverse=True)
    return candidates


def _field_is_missing(asset: CandidateAsset, field_name: str) -> bool:
    """Checks the asset's own missing_metadata_fields list (as carried
    through from ingestion, per the 'never invent' rule) rather than
    guessing from None-ness of a dataclass attribute we may not have mapped
    1:1 to the schema's raw field name."""
    return field_name in asset.missing_metadata_fields


def _audience_market_match_weight(asset: CandidateAsset, slot_state: SlotState, signal: dict) -> float:
    dims = signal.get("dimensions", ["audience", "market", "channel", "campaign"])
    wanted = {
        "audience": slot_state.slots["audience"].value,
        "market": slot_state.slots["market"].value,
        "channel": slot_state.slots["destination_use"].value,
        "campaign": slot_state.slots["campaign"].value,
    }
    have = {
        "audience": asset.audience, "market": asset.market,
        "channel": asset.channel, "campaign": [],
    }
    stated_dims = [d for d in dims if wanted.get(d)]
    if not stated_dims:
        return signal.get("partialMatchWeight", 0.55)  # nothing stated to match against -- treat as partial, not exact

    matches = sum(1 for d in stated_dims if wanted[d] in have.get(d, []))
    if matches == len(stated_dims):
        return signal.get("exactMatchWeight", 1.0)
    if matches > 0:
        return signal.get("partialMatchWeight", 0.55)
    return signal.get("noMatchWeight", 0.10)


def generate_result_cards(
    llm: LLMClient, candidates: list[CandidateAsset], slot_state: SlotState, top_n: int = 3
) -> list[ResultCard]:
    assumed_slots = [name for name, sv in slot_state.slots.items() if sv.source == "assumed"]
    if slot_state.query_intent.source == "assumed":
        assumed_slots = assumed_slots + ["query_intent"]
    cards: list[ResultCard] = []

    for asset in candidates[:top_n]:
        result = llm.call_tool(
            system_prompt=RANKING_EXPLANATION_SYSTEM_PROMPT,
            user_message="Write the rationale for this asset given the extracted intent.",
            tool_schema=WRITE_RATIONALE_TOOL,
            context={
                "asset": {
                    "title": asset.title, "title_source": asset.title_source,
                    "description": asset.description, "description_source": asset.description_source,
                    "topic": asset.topic, "approval_status": asset.approval_status,
                    "lifecycle_status": asset.lifecycle_status, "owner": asset.owner,
                    "content_profile": asset.content_profile, "has_template_link": asset.has_template_link,
                },
                "assumed_slots": assumed_slots,
            },
        )
        cards.append(ResultCard(
            asset_id=asset.asset_id,
            title=asset.title,
            title_flagged_ai_generated=(asset.title_source == "ai_generated"),
            description=asset.description,
            description_flagged_ai_generated=(asset.description_source == "ai_generated"),
            source_system=asset.source_system,
            source_url=asset.source_url,
            approval_status=asset.approval_status,
            lifecycle_status=asset.lifecycle_status,
            owner=asset.owner,
            recommendation_rationale=result["rationale_text"],
            content_profile=asset.content_profile,
            low_confidence=asset.low_confidence,
            use_template_url=asset.template_file_url if asset.has_template_link else None,
            counts_toward_reuse_kpi=(asset.content_profile != "peopleOfficeProfile"),
        ))
    return cards

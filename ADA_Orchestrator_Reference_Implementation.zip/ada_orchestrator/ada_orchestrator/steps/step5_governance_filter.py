"""
Step 5 -- Pre-Search Governance Filter Builder.

Per Cosmos schema Section 8's Query Flow Integration table: "Resolves
approved repositories for the market; pulls each profile's eligibility gate;
validates entities" -- reading repository-governance-rules,
repository-content-profiles, and taxonomy-classification. This replaces the
earlier flat, single-repository-list version with the real per-profile
structure (contentProfile + repositoryId + priority + included), plus each
profile's own eligibility gate fields, so downstream search/ranking can
apply profile-specific rules instead of one generic filter.
"""

from __future__ import annotations

from typing import Any, Optional

from ada_orchestrator.clients.taxonomy_store import TaxonomyStore
from ada_orchestrator.models import CONTENT_PROFILES, SlotState


def build_governance_filter(
    taxonomy: TaxonomyStore,
    slot_state: SlotState,
    market: Optional[str],
) -> dict[str, Any]:
    governance_rule = taxonomy.get_governance_rule(market)
    approved_repos = [r for r in governance_rule.get("approvedRepositories", []) if r.get("included")]
    excluded_repos = [r for r in governance_rule.get("approvedRepositories", []) if not r.get("included")]

    # Eligibility gates per profile -- pulled from repository-content-profiles,
    # not hardcoded. "Never invent" applies here too: a field only ends up in
    # a profile's gate list because Cosmos DB says so.
    eligibility_gates: dict[str, dict[str, list[str]]] = {}
    for profile in CONTENT_PROFILES:
        doc = taxonomy.get_content_profile(profile)
        if doc:
            eligibility_gates[profile] = {
                "primary": doc.get("primaryEligibilityGate", []),
                "secondary": doc.get("secondaryEligibilityGate", []),
            }

    subject = slot_state.slots["asset_subject"].value
    person_query = slot_state.slots["person_query"].value

    return {
        "market": market,
        "approved_repositories": approved_repos,   # [{contentProfile, repositoryId, priority}, ...]
        "excluded_repositories": excluded_repos,    # kept for traceability/telemetry, e.g. Brightcove
        "eligibility_gates": eligibility_gates,      # per-profile fields that gate eligibility, never invented
        "rights_constraints": governance_rule.get("rightsConstraints", {}),
        "asset_format": slot_state.slots["asset_format"].value,
        "destination_use": slot_state.slots["destination_use"].value,
        "subject_terms": [subject] if subject else [],
        "person_query": person_query,
        "query_intent": slot_state.query_intent.value,
    }

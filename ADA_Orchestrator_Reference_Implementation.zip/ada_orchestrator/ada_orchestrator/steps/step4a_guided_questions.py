"""
Step 4a -- Guided Question Loop / Intent Collection (hybrid).

Per the client's explicit direction: intent gathering is NOT "automatic
Cosmos classification OR guided questions" -- it's both, feeding the same
state. This step handles the "ask the user directly" half, in two distinct
situations:

  1. Ambiguous intent -- Step 4 classified query_intent, but with low/medium
     confidence, or the Cosmos taxonomy doc flags that two intents are easily
     confused (e.g. templateRequest vs brandGuidelineLookup share a content
     profile and only differ by whether a concrete deliverable was named).
     This step asks the user to disambiguate directly, in plain language --
     never exposing the internal intent code name.
  2. Missing relevant slot -- once intent is known (confidently, from either
     path), SlotState.relevant_slots() (models.py, driven by
     INTENT_RELEVANT_SLOTS) tells us which slots actually matter for THAT
     intent. Only those are asked about -- a people-lookup query is never
     asked about "asset_format".

Either way, the round cap and the "proceed with assumptions" fallback are
shared -- this remains bounded, per Addendum Section 2.3/2.8.
"""

from __future__ import annotations

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.clients.taxonomy_store import TaxonomyStore
from ada_orchestrator.models import ClarifyingQuestion, DEFAULT_ROUND_CAP, SlotState
from ada_orchestrator.prompts import GUIDED_QUESTION_SYSTEM_PROMPT
from ada_orchestrator.tools import ASK_CLARIFYING_QUESTION_TOOL


def resolve_pending_intent_answer(
    llm: LLMClient, taxonomy: TaxonomyStore, candidate_intents: list[str], user_message: str
) -> str | None:
    """
    Called by the orchestrator when the PRIOR turn's clarifying question
    targeted query_intent (thread.pending_clarifying_question.slot ==
    "query_intent") -- resolves the user's free-text answer against ONLY the
    candidates that were actually offered, then the caller is expected to
    apply it via SlotState.set_query_intent_from_user_answer(), which marks
    it "stated"/"high" so it can't be silently overwritten by a later
    generic re-classification of the same message.

    Reuses the same extract_intent tool/prompt as Step 4, just scoped to the
    two (or more) offered candidates' detection cues -- this keeps exactly
    one code path responsible for mapping text to an intent value, rather
    than a second, separately-tuned matcher for "answers to disambiguation
    questions" specifically.
    """
    from ada_orchestrator.prompts import QUERY_UNDERSTANDING_SYSTEM_PROMPT
    from ada_orchestrator.tools import EXTRACT_INTENT_TOOL

    all_cues = taxonomy.get_query_intent_detection_cues()
    restricted_cues = {k: v for k, v in all_cues.items() if k in candidate_intents}

    extracted = llm.call_tool(
        system_prompt=QUERY_UNDERSTANDING_SYSTEM_PROMPT,
        user_message=user_message,
        tool_schema=EXTRACT_INTENT_TOOL,
        context={
            "valid_query_intents": candidate_intents,
            "query_intent_detection_cues": restricted_cues,
            "query_intent_fallback_value": candidate_intents[0] if candidate_intents else "unspecified",
            "situation": "resolving_disambiguation_answer",
        },
    )
    value = extracted.get("query_intent", {}).get("value")
    return value if value in candidate_intents else None


def run_guided_question_step(
    llm: LLMClient,
    taxonomy: TaxonomyStore,
    slot_state: SlotState,
    round_cap: int = DEFAULT_ROUND_CAP,
) -> tuple[bool, ClarifyingQuestion | None]:
    if slot_state.round_count >= round_cap:
        _proceed_with_assumptions(slot_state)
        return False, None

    # Case 1: ambiguous intent takes priority over slot questions -- knowing
    # the intent changes which slots even matter (relevant_slots() reads
    # query_intent), so resolving it first avoids asking a slot question
    # that turns out to be irrelevant once intent is clarified.
    if slot_state.intent_is_ambiguous():
        cues = taxonomy.get_query_intent_detection_cues()
        intent_doc = taxonomy.get_taxonomy_domain("queryIntent")
        candidate_intents = _likely_candidates(slot_state, intent_doc)
        result = llm.call_tool(
            system_prompt=GUIDED_QUESTION_SYSTEM_PROMPT,
            user_message="Intent is ambiguous -- ask the disambiguating question.",
            tool_schema=ASK_CLARIFYING_QUESTION_TOOL,
            context={
                "situation": "ambiguous_intent",
                "candidate_intents": candidate_intents,
                "detection_notes": intent_doc.get("detectionNotes", ""),
                "cues": {k: cues.get(k, []) for k in candidate_intents},
            },
        )
        slot_state.round_count += 1
        return True, ClarifyingQuestion(
            slot="query_intent", question_text=result["question_text"],
            options=result.get("options_shown", []),
        )

    # Case 2: missing slot relevant to the (now trusted-enough) intent.
    missing = slot_state.missing_critical_slots()
    if not missing:
        return False, None

    target_slot = missing[0]
    options = taxonomy.get_taxonomy_options(target_slot)

    result = llm.call_tool(
        system_prompt=GUIDED_QUESTION_SYSTEM_PROMPT,
        user_message=(
            f"Missing/low-confidence slots relevant to intent "
            f"'{slot_state.query_intent.value}', in priority order: {missing}. "
            f"Ask about '{target_slot}' first."
        ),
        tool_schema=ASK_CLARIFYING_QUESTION_TOOL,
        context={"situation": "missing_slot", "target_slot": target_slot, "options": options},
    )

    slot_state.round_count += 1
    return True, ClarifyingQuestion(
        slot=result["target_slot"], question_text=result["question_text"],
        options=result.get("options_shown", []),
    )


def _likely_candidates(slot_state: SlotState, intent_doc: dict) -> list[str]:
    """Prefer the ACTUAL tied candidates surfaced by classification
    (SlotState.query_intent_candidates, set when Step 4's classifier hit a
    genuine tie -- see MockAzureOpenAIClient._extract_intent /
    RANKING's real-model equivalent). Falls back to a generic pairing only
    when that information isn't available (e.g. an older client that hasn't
    been updated to report ties)."""
    if len(slot_state.query_intent_candidates) >= 2:
        return slot_state.query_intent_candidates[:2]

    current = slot_state.query_intent.value
    if current and current != "unspecified":
        all_values = [v["value"] for v in intent_doc.get("values", [])]
        others = [v for v in all_values if v != current and v != "unspecified"]
        return [current] + others[:1]
    return ["templateRequest", "brandGuidelineLookup"]


def _proceed_with_assumptions(slot_state: SlotState) -> None:
    missing = slot_state.missing_critical_slots()
    if missing:
        slot_state.mark_assumed(missing)
    if slot_state.intent_is_ambiguous():
        slot_state.assumptions_made = True  # ranking will use whatever intent value is currently held,
                                             # low-confidence or not, rather than asking indefinitely

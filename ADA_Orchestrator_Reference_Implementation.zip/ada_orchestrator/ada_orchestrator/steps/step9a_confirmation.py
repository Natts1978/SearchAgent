"""
Step 9a (NEW) -- Result Confirmation Checkpoint (Addendum Section 2.5).

Distinct from open-ended conversational refinement (Step 11): this is a
deliberate, always-shown confirm/refine prompt returned alongside every
result-card response, per the client's recommended flow (gather intent ->
search -> present -> explain -> confirm/refine).
"""

from __future__ import annotations

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.prompts import RESULT_CONFIRMATION_SYSTEM_PROMPT
from ada_orchestrator.tools import WRITE_CONFIRMATION_PROMPT_TOOL


def build_confirmation_prompt(llm: LLMClient, result_count: int, assumptions_made: bool) -> str:
    result = llm.call_tool(
        system_prompt=RESULT_CONFIRMATION_SYSTEM_PROMPT,
        user_message="Write the confirmation prompt for these results.",
        tool_schema=WRITE_CONFIRMATION_PROMPT_TOOL,
        context={"result_count": result_count, "assumptions_made": assumptions_made},
    )
    return result["prompt_text"]

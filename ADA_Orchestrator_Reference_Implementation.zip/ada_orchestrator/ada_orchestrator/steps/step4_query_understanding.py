"""
Step 4 -- Query Understanding.

Extracts W/X/Y/Z + existing ADA slots AND classifies query_intent from the
user's message via a forced tool call, then merges the result into the
thread's persistent SlotState (Step 3a's Cosmos-backed Thread).

query_intent classification is grounded in Cosmos DB's business-owned
detection cues (taxonomy-classification container, doc "taxonomy::queryIntent")
-- this is the "automatic" half of the client's hybrid direction. The cues
and valid intent values are fetched fresh from TaxonomyStore on every call
and passed into the LLM's context rather than hardcoded into the prompt, so
a business-owner edit to the cues in Cosmos DB takes effect without a code
deploy. If the model returns an intent value that isn't currently in the
taxonomy (e.g. stale/hallucinated), it's rejected and treated as
"unspecified" rather than trusted -- see `_sanitize_query_intent`.
"""

from __future__ import annotations

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.clients.taxonomy_store import TaxonomyStore
from ada_orchestrator.models import SlotState
from ada_orchestrator.prompts import QUERY_UNDERSTANDING_SYSTEM_PROMPT
from ada_orchestrator.tools import EXTRACT_INTENT_TOOL


def run_query_understanding(
    llm: LLMClient, taxonomy: TaxonomyStore, user_message: str, slot_state: SlotState
) -> SlotState:
    intent_taxonomy = taxonomy.get_taxonomy_domain("queryIntent")
    valid_intents = [v["value"] for v in intent_taxonomy.get("values", [])]
    detection_cues = taxonomy.get_query_intent_detection_cues()

    extracted = llm.call_tool(
        system_prompt=QUERY_UNDERSTANDING_SYSTEM_PROMPT,
        user_message=user_message,
        tool_schema=EXTRACT_INTENT_TOOL,
        context={
            "already_known_slots": slot_state.as_dict(),
            "valid_query_intents": valid_intents,
            "query_intent_detection_cues": detection_cues,
            "query_intent_fallback_value": "unspecified",
        },
    )

    extracted = _sanitize_query_intent(extracted, valid_intents)
    slot_state.merge(extracted)
    return slot_state


def _sanitize_query_intent(extracted: dict, valid_intents: list[str]) -> dict:
    """Never trust a query_intent value outside the current Cosmos DB
    taxonomy -- reject and fall back to 'unspecified' rather than let a
    stale/hallucinated category silently drive Step 4b's boost lookup."""
    qi = extracted.get("query_intent")
    if qi and qi.get("value") not in valid_intents:
        extracted["query_intent"] = {"value": "unspecified", "confidence": "none"}
    return extracted

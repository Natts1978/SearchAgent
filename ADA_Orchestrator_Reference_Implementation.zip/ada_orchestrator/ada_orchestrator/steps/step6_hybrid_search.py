"""
Step 6 -- Query Embedding + Hybrid Search | RAG Store.

Vectorizes the query and fires a hybrid keyword+vector+governed-filter
search against the unified Azure AI Search index -- ADA's RAG store
(Cosmos schema Section 8: "Azure AI Search only -- no source-specific
branching at this step").

CORRECTED: this step no longer applies any content-profile/source weighting
itself -- per the Cosmos schema's Section 8 Query Flow Integration table,
trust-ranking-signals is read at Step 8, not here. Step 6's only job is
retrieval under the governance filter (approved repositories per profile,
eligibility gates, subject/format/destination match) -- ranking and boosting
happen entirely in Step 8.
"""

from __future__ import annotations

from typing import Any

from ada_orchestrator.clients.azure_openai_client import LLMClient
from ada_orchestrator.clients.search_client import SearchClient
from ada_orchestrator.models import CandidateAsset


def run_hybrid_search(
    llm: LLMClient,
    search: SearchClient,
    query_text: str,
    query_vector: list[float],
    governed_filter: dict[str, Any],
    top_k: int = 10,
) -> list[CandidateAsset]:
    return search.hybrid_search(
        query_text=query_text, query_vector=query_vector, governed_filter=governed_filter, top_k=top_k
    )

"""
Step 7 -- Live Governance / Permission Check | SharePoint Only.

SharePoint ACLs are more dynamic than Adobe's approval/lifecycle fields, so a
lightweight live permission check is retained specifically for SharePoint
results (Solution Approach Section 2.2.1). Adobe DAM / EY.com results are
trusted directly from the near-real-time index. This step also enforces the
final restricted-content suppression regardless of source.
"""

from __future__ import annotations

from ada_orchestrator.models import CandidateAsset, SourceSystem


class PermissionChecker:
    """Interface for the live SharePoint permission check."""

    def user_can_access(self, user_id: str, asset: CandidateAsset) -> bool:
        raise NotImplementedError


class RealGraphPermissionChecker(PermissionChecker):
    """Production: calls Microsoft Graph to verify the current user's access
    to the SharePoint item behind `asset.source_url` (batched via $batch when
    checking multiple candidates)."""

    def __init__(self, graph_client: Any):
        self._graph_client = graph_client

    def user_can_access(self, user_id: str, asset: CandidateAsset) -> bool:
        raise NotImplementedError("Wire to Microsoft Graph permission check in production.")


class MockPermissionChecker(PermissionChecker):
    """Mock: everything is accessible unless explicitly restricted_flag=True,
    which the search step already filters out -- this exists so the pipeline
    shape matches production even though the mock has nothing to deny."""

    def user_can_access(self, user_id: str, asset: CandidateAsset) -> bool:
        return not asset.restricted_flag


def apply_live_permission_check(checker: PermissionChecker, user_id: str, candidates: list[CandidateAsset]) -> list[CandidateAsset]:
    allowed = []
    for asset in candidates:
        if asset.restricted_flag:
            continue
        if asset.source_system == SourceSystem.SHAREPOINT.value:
            if not checker.user_can_access(user_id, asset):
                continue
        allowed.append(asset)
    return allowed

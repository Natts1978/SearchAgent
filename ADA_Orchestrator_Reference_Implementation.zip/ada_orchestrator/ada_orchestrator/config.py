"""
Configuration. In production these come from Azure App Configuration /
Key Vault (engineering-owned config), per Solution Approach Section 2.2 --
never hardcoded and never mixed with the CIL Metadata Store's business-owned
governance/taxonomy config, which is fetched at runtime via TaxonomyStore.
"""

import os

AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "")
AZURE_OPENAI_CHAT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4o-mini")
AZURE_OPENAI_EMBEDDING_DEPLOYMENT = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")

AZURE_SEARCH_ENDPOINT = os.environ.get("AZURE_SEARCH_ENDPOINT", "")
AZURE_SEARCH_API_KEY = os.environ.get("AZURE_SEARCH_API_KEY", "")
AZURE_SEARCH_INDEX_NAME = os.environ.get("AZURE_SEARCH_INDEX_NAME", "ada-unified-index")

# --- Azure AI Foundry Agent Service -----------------------------------------
# The orchestrator's LLM steps (4, 4a, 4b, 8, 9a) can be served either by
# calling Azure OpenAI chat completions directly (RealAzureOpenAIClient), or
# by delegating to a Foundry "Coded Agent" -- a Foundry Agent Service agent
# whose implementation is custom code we control, invoked via Threads/Runs
# instead of a raw chat completion. See clients/foundry_agent_client.py.
#
# USE_FOUNDRY_CODED_AGENT selects which backend `build_dependencies()` wires
# up when ADA_USE_MOCK_CLIENTS=false. It has no effect in mock mode.
USE_FOUNDRY_CODED_AGENT = os.environ.get("ADA_USE_FOUNDRY_CODED_AGENT", "false").lower() == "true"

AZURE_AI_PROJECT_ENDPOINT = os.environ.get("AZURE_AI_PROJECT_ENDPOINT", "")  # Foundry project endpoint
FOUNDRY_CODED_AGENT_ID = os.environ.get("FOUNDRY_CODED_AGENT_ID", "")        # agent id registered in Foundry
FOUNDRY_MODEL_DEPLOYMENT = os.environ.get("FOUNDRY_MODEL_DEPLOYMENT", "gpt-4o-mini")
FOUNDRY_RUN_POLL_INTERVAL_SECONDS = float(os.environ.get("FOUNDRY_RUN_POLL_INTERVAL_SECONDS", "0.5"))
FOUNDRY_RUN_TIMEOUT_SECONDS = float(os.environ.get("FOUNDRY_RUN_TIMEOUT_SECONDS", "30"))

COSMOS_ENDPOINT = os.environ.get("COSMOS_ENDPOINT", "")
COSMOS_KEY = os.environ.get("COSMOS_KEY", "")
COSMOS_DATABASE = os.environ.get("COSMOS_DATABASE", "cil-metadata-store")
COSMOS_THREAD_CONTAINER = os.environ.get("COSMOS_THREAD_CONTAINER", "ada-thread-mapping")

# The five containers of the confirmed CIL Metadata Store schema
# (CIL_ADA_CosmosDB_Schema_Final_Consolidated.docx, Section 2). All five live
# in COSMOS_DATABASE above -- this is a container split within one database,
# not five separate accounts.
COSMOS_CONTENT_PROFILES_CONTAINER = os.environ.get("COSMOS_CONTENT_PROFILES_CONTAINER", "repository-content-profiles")
COSMOS_TAXONOMY_CONTAINER = os.environ.get("COSMOS_TAXONOMY_CONTAINER", "taxonomy-classification")
COSMOS_SIGNALS_CONTAINER = os.environ.get("COSMOS_SIGNALS_CONTAINER", "trust-ranking-signals")
COSMOS_GOVERNANCE_CONTAINER = os.environ.get("COSMOS_GOVERNANCE_CONTAINER", "repository-governance-rules")
COSMOS_FIELD_MAPPING_CONTAINER = os.environ.get("COSMOS_FIELD_MAPPING_CONTAINER", "source-field-mapping")

REDIS_CONNECTION_STRING = os.environ.get("REDIS_CONNECTION_STRING", "")
SEMANTIC_CACHE_TTL_SECONDS = int(os.environ.get("SEMANTIC_CACHE_TTL_SECONDS", "1200"))  # 20 min, within 15-30 min band
SEMANTIC_CACHE_SIMILARITY_THRESHOLD = float(os.environ.get("SEMANTIC_CACHE_SIMILARITY_THRESHOLD", "0.95"))

# Embedding model version pin (Solution Approach Section 2.3.5 -- drift detection)
EMBEDDING_MODEL_VERSION = os.environ.get("EMBEDDING_MODEL_VERSION", "text-embedding-3-small-v1")

USE_MOCK_CLIENTS = os.environ.get("ADA_USE_MOCK_CLIENTS", "true").lower() == "true"

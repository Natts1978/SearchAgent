# ADA Orchestrator -- Reference Implementation

Reference implementation of the Asset Discovery Agent (ADA) orchestration
pipeline, matching the confirmed architecture in the CIL/ADA Solution
Approach (v0.2), the ADA Detailed Documentation, and the Solution Approach
Addendum v0.3 (guided intent collection, source prioritization, result
confirmation).

Runs end-to-end with **no Azure credentials** using in-memory mocks, so you
can inspect and demo the guided-question loop, source weighting, and grounded
ranking logic directly. Swap the mocks for the real clients (already stubbed
in each `clients/*.py` file) to go to production -- **no orchestration logic
changes**.

## Quick start

```bash
pip install -r requirements.txt        # only azure-functions is required for the demo
python example_run.py                  # runs 5 example conversations end to end
python test_orchestrator.py            # unit tests (round cap, hybrid intent, Cosmos weighting, permission check)
```

## Architecture correction: Cosmos DB schema alignment (this revision)

Reviewing `CIL_ADA_CosmosDB_Schema_Final_Consolidated.docx` against the
earlier version of this code surfaced a real design error, now fixed:

**Before:** Step 4b was a separate LLM call that freely decided per-source
ranking weights from the raw user message.

**Actual confirmed design:** `queryIntent` is classified INSIDE Step 4 (the
same call that extracts W/X/Y/Z), grounded in business-owned detection cues
stored in Cosmos DB (`taxonomy-classification` container). The weights that
prioritize results are then a **deterministic matrix lookup**
(`trust-ranking-signals::intentProfileBoost`), applied in Step 8 -- never an
LLM decision.

Per the client's explicit hybrid direction, intent-gathering now has two
paths feeding the *same* `SlotState.query_intent` field:

1. **Automatic** -- Step 4's classifier matches the user's message against
   Cosmos DB's `detectionCues`, sets `source="inferred"`.
2. **Guided** -- Step 4a asks the user directly, either to fill a missing
   slot relevant to the known intent, or (new) to disambiguate the intent
   itself when classification was a genuine tie (e.g. `templateRequest` vs
   `brandGuidelineLookup`). A direct answer sets `source="stated"`, which a
   later generic re-classification can no longer downgrade
   (`SlotState.merge()`'s guard).

Either way, **Step 8 always resolves weights from the same Cosmos DB
matrix** -- there is exactly one place ranking weights come from, regardless
of which path produced the intent. See
`steps/step4b_source_priority.py` (now a pure lookup, no LLM call) and
`steps/step8_ranking_explanation.py` (the full combined-score formula from
the schema's Section 5: relevance × intentProfileBoost × templateLinkBoost
× sourceDataQualityWeight × completeness penalty × audienceMarketMatch).

### Schema review -- recommended changes (not yet made in Cosmos DB)

| # | Finding | Recommendation |
|---|---|---|
| 1 | No `userRole` taxonomy domain exists in the confirmed schema -- needed for W/X/Y/Z's "W" slot. | Add a `taxonomy::userRole` document so guided questions for it can offer grounded options instead of falling back to an open question. |
| 2 | `destination_use` (Z) maps to the existing `channel` dimension, but examples given ("ey.com webpage", "LinkedIn post") are more specific than any enumerated `channel` domain shown in the schema. | Confirm whether `channel`'s value set already covers these, or add a finer `destination` sub-domain. |
| 3 | G1 (open in the schema doc): `aiTitle`/`aiDescription`/`aiKeyword` marked BMC-DAM-only in the field-mapping workbook, contradicting the confirmed narrative that Adobe DAM skips AI enrichment. | Resolve before ingestion sign-off -- this code assumes Adobe DAM titles/descriptions are always source-authored (`title_source="source"`); if G1 resolves the other way, `search_client.py`'s mock and the real ingestion mapping both need updating. |
| 4 | Round cap (`DEFAULT_ROUND_CAP`) and critical/relevant-slot lists (`INTENT_RELEVANT_SLOTS`) are Python-side constants in `models.py`, not Cosmos DB documents. | Migrate into Cosmos DB once the client confirms values, consistent with "BMC owns the brain" -- these are exactly the kind of business-tunable parameters the rest of the schema keeps out of code. |
| 5 | `templateLinkBoost` and `metadataCompletenessThresholds` are read correctly, but nothing in the schema flags which specific fields are `eligibilityOnly` (never vectorized) at query time -- that flag currently only lives in `source-field-mapping`, an ingestion-time container this client doesn't read. | Low risk today (ingestion enforces it), but if a future profile needs a query-time eligibility-only check, consider surfacing an `eligibilityOnlyFields` list on `repository-content-profiles` directly, so query-time code doesn't need to read the ingestion-time container. |



## Architecture-to-code map

| Flow step | Module | System prompt (if any) |
|---|---|---|
| 1-2. User request, channel submit | *(outside this package -- Teams/Copilot connector)* | -- |
| 3. Orchestrator entry (APIM + Entra ID upstream) | `function_app.py` | -- |
| 3a. Conversation continuity | `steps/step3a_conversation.py` + `clients/thread_store.py` | -- |
| 4. Query Understanding + queryIntent classification | `steps/step4_query_understanding.py` | `prompts.QUERY_UNDERSTANDING_SYSTEM_PROMPT` |
| 4a. Guided Question Loop -- missing slot OR ambiguous intent **(NEW)** | `steps/step4a_guided_questions.py` | `prompts.GUIDED_QUESTION_SYSTEM_PROMPT` |
| 4b. Source/profile prioritization -- **deterministic Cosmos DB lookup, no LLM** **(CORRECTED)** | `steps/step4b_source_priority.py` | -- (no prompt; matrix lookup) |
| 4c. Semantic Query Cache | `steps/step4c_semantic_cache.py` + `clients/semantic_cache.py` | -- |
| 5. Pre-Search Governance Filter (per-profile eligibility gates) | `steps/step5_governance_filter.py` + `clients/taxonomy_store.py` | -- |
| 6. Query Embedding + Hybrid Search (RAG store) -- retrieval only, no weighting | `steps/step6_hybrid_search.py` + `clients/search_client.py` | -- |
| 7. Live Governance/Permission Check (SharePoint only) | `steps/step7_live_permission_check.py` | -- |
| 8. Ranking (Cosmos boost matrix + templateLinkBoost + completeness + audience/market match) + Explanation | `steps/step8_ranking_explanation.py` | `prompts.RANKING_EXPLANATION_SYSTEM_PROMPT` |
| 9. Governed result cards | *(returned by Step 8)* | -- |
| 9a. Result Confirmation **(NEW)** | `steps/step9a_confirmation.py` | `prompts.RESULT_CONFIRMATION_SYSTEM_PROMPT` |
| 10. User action | *(outside this package -- resolved at source system)* | -- |
| 11. Conversational refinement | *(next call to `run_turn()` on the same thread)* | -- |
| 12. Telemetry | `clients/telemetry_client.py`, called throughout `orchestrator.py` | -- |

Four system prompts live in **`prompts.py`** in one place for governance
review (the earlier "source prioritization" prompt was removed -- see the
architecture correction section above). Each is paired with a forced
tool/function schema in **`tools.py`** so the model's output shape is
enforced by the API call, not just requested in the prompt text.

## Package layout

```
ada_orchestrator/
  ada_orchestrator/
    __init__.py
    config.py                    # env-driven config, incl. Foundry settings (Azure App Config / Key Vault in production)
    models.py                    # SlotState, ThreadState (+ foundry_thread_id), CandidateAsset, ResultCard, etc.
    prompts.py                   # ALL system prompts
    tools.py                     # ALL tool/function-calling schemas
    orchestrator.py              # run_turn() -- wires every step together
    clients/
      azure_openai_client.py     # LLM client (real + mock) -- direct Azure OpenAI backend
      foundry_agent_client.py    # LLM client (real) -- Foundry Coded Agent backend, Threads/Runs
      search_client.py           # Azure AI Search client (real + mock catalog)
      thread_store.py            # Cosmos DB conversation/thread store (real + mock), Foundry-aware
      semantic_cache.py          # Redis semantic cache (real + mock)
      taxonomy_store.py          # CIL Metadata Store: taxonomy + governance (real + mock)
      telemetry_client.py        # App Insights / Log Analytics (real + mock)
    steps/
      step3a_conversation.py
      step4_query_understanding.py
      step4a_guided_questions.py     # NEW
      step4b_source_priority.py      # NEW
      step4c_semantic_cache.py
      step5_governance_filter.py
      step6_hybrid_search.py
      step7_live_permission_check.py
      step8_ranking_explanation.py
      step9a_confirmation.py         # NEW
  foundry_coded_agent/
    handler.py                   # server-side implementation Foundry invokes for ADA's Coded Agent
  function_app.py                # Azure Functions HTTP entry point (Step 3)
  example_run.py                 # runnable demo, no credentials required
  test_orchestrator.py           # unit tests
  requirements.txt
  host.json
  local.settings.json.example
```

## Design points worth knowing before you extend this

- **Channel-agnostic by construction.** `function_app.py` is the only HTTP
  surface. Teams and Copilot connectors both call the same
  `/ada/orchestrator` route with the same request shape -- no per-channel
  orchestration logic, per Solution Approach Section 2.3.4.
- **Guided questions never invent options.** `steps/step4a_guided_questions.py`
  sources its option list from `TaxonomyStore.get_taxonomy_options()` --
  the CIL Metadata Store in production. The LLM prompt (`GUIDED_QUESTION_SYSTEM_PROMPT`)
  explicitly forbids fabricating options beyond what it's given.
- **Source prioritization is a weight, never a filter.** `SET_SOURCE_WEIGHTS_TOOL`
  constrains output to `[0.5, 1.5]` -- there is no schema-level way for the
  model to zero out a source. See Addendum Section 2.4 for the rationale.
- **Round cap and critical-slot list are placeholders.** `models.CRITICAL_SLOTS`
  and `models.DEFAULT_ROUND_CAP` are explicitly flagged in-code as pending the
  client's persona decision (Addendum Section 1.2/2.3) -- change them in one
  place, not scattered through the pipeline.
- **Never-invent governance rule is enforced at the prompt AND the data
  layer.** `RANKING_EXPLANATION_SYSTEM_PROMPT` tells the model not to cite
  fields it wasn't given -- and `step8_ranking_explanation.py` only ever
  passes fields that are actually present on the `CandidateAsset` into the
  prompt context, so there's nothing to hallucinate from even if the model
  ignored the instruction.
- **Assumed vs. stated is tracked per slot**, not just as one global flag.
  `SlotValue.source` is `"stated"` or `"assumed"`; the result-card rationale
  and the Step 9a confirmation prompt both read this to decide whether to
  flag anything to the user.

## Foundry Agent Service integration

This maps directly onto the confirmed architecture (Solution Approach
Section 2.3.3, ADA Detailed Documentation Section 6.3, and the "AI Foundry
Agent Service (Foundry Threads)" + "Azure OpenAI GPT" boxes in the
architecture diagram):

| Architecture requirement | Where it's implemented |
|---|---|
| Foundry Threads with Bring-Your-Own Cosmos DB storage, in the same account as the CIL Metadata Store | `clients/foundry_agent_client.py: FoundryThreadResolver` creates real Foundry threads; `clients/thread_store.py: RealCosmosThreadStore` persists the `(channel, external_conversation_id) -> foundry_thread_id` mapping in a dedicated container |
| Thread continuity across turns ("prior turns, filters, results already shown") | `orchestrator.run_turn()` calls `deps.llm.set_active_thread(thread.foundry_thread_id)` once per turn, before Steps 4/4a/4b/8/9a run -- every LLM call in the turn shares one Foundry Thread |
| Per-agent AI Orchestration (ADA, CGE, SBA each get their own agent) | `FoundryCodedAgentClient` is ADA-specific (`FOUNDRY_CODED_AGENT_ID` config) -- CGE/SBA would each get their own agent id and client instance in Phase 3, not a shared one |
| Foundry observability as a named Observability & Audit capability | Every `call_tool()` on the Foundry path runs as a Foundry Run against a real Thread, so Foundry's own tracing wraps it in addition to the existing App Insights telemetry calls |

**Two production LLM backends, selected by `ADA_USE_FOUNDRY_CODED_AGENT`:**

- `false` (default): `RealAzureOpenAIClient` calls Azure OpenAI chat
  completions directly. Simplest path; no Foundry Thread, so
  `ThreadState.foundry_thread_id` stays `None` and continuity is tracked only
  in the Cosmos-backed `SlotState`/`prior_results` fields already in
  `thread_store.py`.
- `true`: `FoundryCodedAgentClient` (`clients/foundry_agent_client.py`) sends
  each step's request to **ADA's Foundry Coded Agent** via a real
  Thread + Run, and reads the structured tool-call result back from the
  run's `requires_action` state.

**Why a Coded Agent instead of a plain Foundry agent:** ADA needs five
distinct system prompts/tool schemas depending on which step is calling
(Query Understanding, Guided Question, Source Prioritization,
Ranking+Explanation, Confirmation). A static Foundry agent definition (one
`instructions` field, one toolset) can't switch behavior per call. A Coded
Agent's implementation is our own code, so it can route on the `step` field
in the message payload -- see `foundry_coded_agent/handler.py`, which is a
**separate deployable unit** from `function_app.py`: it's what Foundry
invokes server-side, not something that runs inside the Azure Function.

The handler reuses `prompts.py`/`tools.py` directly and fails loudly
(`RuntimeError`) if the orchestrator and the deployed Coded Agent ever send
mismatched tool schemas for the same step -- see
`test_orchestrator.py: test_coded_agent_handler_dispatches_by_step_name`.

**What does *not* go through Foundry:** query embedding (Step 6) still calls
the Azure OpenAI embedding deployment directly in both backends, matching
the architecture diagram's separate "Azure OpenAI / Foundry embedding model"
box -- Foundry Agent Runs produce chat/tool responses, not raw embedding
vectors, so there's nothing to route through a Run for that step.

**SDK surface caveat:** `azure-ai-projects`/`azure-ai-agents` method names
have shifted across Foundry Agent Service preview releases. The call
sequence in `foundry_agent_client.py` (create/get thread, create message,
create run, poll, read `requires_action`, submit tool outputs) is the stable
*protocol* -- verify exact method names against current SDK docs at deploy
time.

## Going to production

1. Set `ADA_USE_MOCK_CLIENTS=false` and populate the real endpoint/key
   settings in `local.settings.json` (or Azure App Configuration / Key Vault
   references, per Solution Approach Section 2.2's business/engineering
   config split).
2. Decide `ADA_USE_FOUNDRY_CODED_AGENT` (see previous section). If `true`,
   register ADA's Coded Agent in your Foundry project first and set
   `FOUNDRY_CODED_AGENT_ID` / `AZURE_AI_PROJECT_ENDPOINT`.
3. Implement `RealRedisSemanticCache.get/set` (`clients/semantic_cache.py`) --
   left as a stub with the exact RediSearch call pattern noted, since it
   depends on your Redis Enterprise index configuration.
4. Implement `RealGraphPermissionChecker.user_can_access`
   (`steps/step7_live_permission_check.py`) against Microsoft Graph, batched
   via `$batch` per the ingestion pipeline's existing throttling pattern.
5. Point `RealCosmosThreadStore` and `RealCosmosTaxonomyStore` at the actual
   CIL Metadata Store account -- keep them in **separate containers**, per
   the Section 2.3.1 business-config/engineering-config separation principle,
   even though both use Cosmos DB.
6. Wire `RealAppInsightsTelemetryClient` to your Azure Monitor exporter and
   confirm correlation IDs propagate from APIM through to Log Analytics /
   Purview, per the audit-trail requirement in the BRD.

## What this does *not* include (by design)

- The ingestion pipeline (Adobe/SharePoint listeners, Azure Data Factory
  backfill, embedding generation at index time) -- that's a separate service,
  documented in the Solution Approach Section 2.2.1/2.3.1.
- Teams/Copilot channel connector UI code (adaptive cards, etc.) -- those are
  thin clients of `function_app.py` and are out of scope for the
  orchestrator itself.
- Persona-specific critical-slot tuning and the final round-cap value --
  both are open client decisions (see Addendum Section 1.2) and are left as
  clearly marked configuration, not hardcoded assumptions.

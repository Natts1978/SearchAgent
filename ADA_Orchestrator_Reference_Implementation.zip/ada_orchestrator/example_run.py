"""
Runnable, dependency-light demo of the ADA Orchestrator using the mock
clients -- no Azure credentials required.

Reproduces the three example conversations discussed earlier:
  1. A well-specified query (no clarification needed).
  2. An under-specified query (one guided-question round, then resolves).
  3. An ambiguous query that hits the round cap and proceeds with an
     explicit "assumed" flag.

Run with:  python example_run.py
"""

from ada_orchestrator.orchestrator import build_dependencies, run_turn


def print_response(label, response):
    print(f"\n--- {label} ---")
    print(f"status: {response.status}")
    if response.clarifying_question:
        q = response.clarifying_question
        print(f"ADA asks ({q.slot}): {q.question_text}")
        if q.options:
            print(f"  options offered: {q.options}")
    if response.result_cards:
        print(f"assumptions_made: {response.assumptions_made}")
        for i, card in enumerate(response.result_cards, 1):
            print(f"  [{i}] {card.title}  ({card.source_system})")
            print(f"      rationale: {card.recommendation_rationale}")
        if response.confirmation_prompt:
            print(f"ADA: {response.confirmation_prompt}")


def example_1_well_specified():
    deps = build_dependencies(use_mock=True)
    resp = run_turn(
        deps, channel="teams", external_conversation_id="conv-1", user_id="user-1",
        user_message="I am a marketer looking for an image that represents AI transformation for a CFO audience in the US, to use on an ey.com webpage.",
        market="US",
    )
    print_response("Example 1: well-specified query", resp)


def example_2_one_clarification_round():
    deps = build_dependencies(use_mock=True)
    conv_id = "conv-2"

    resp1 = run_turn(deps, channel="teams", external_conversation_id=conv_id, user_id="user-2",
                      user_message="I need something for a CFO campaign")
    print_response("Example 2, turn 1 (under-specified)", resp1)

    assert resp1.status == "clarifying_question"

    resp2 = run_turn(deps, channel="teams", external_conversation_id=conv_id, user_id="user-2",
                      user_message="UK market, and it's about resilience and risk management, needed as a document.")
    print_response("Example 2, turn 2 (partial answer -- role still missing)", resp2)

    if resp2.status == "clarifying_question":
        resp3 = run_turn(deps, channel="teams", external_conversation_id=conv_id, user_id="user-2",
                          user_message="I'm a marketer.")
        print_response("Example 2, turn 3 (role provided -- resolves)", resp3)


def example_3_round_cap_hit():
    deps = build_dependencies(use_mock=True)
    conv_id = "conv-3"

    resp1 = run_turn(deps, channel="copilot", external_conversation_id=conv_id, user_id="user-3",
                      user_message="Show me some good content")
    print_response("Example 3, turn 1 (ambiguous)", resp1)
    assert resp1.status == "clarifying_question"

    resp2 = run_turn(deps, channel="copilot", external_conversation_id=conv_id, user_id="user-3",
                      user_message="Just anything recent that's performed well")
    print_response("Example 3, turn 2 (still ambiguous)", resp2)

    # Depending on round cap (default 2), this may already have proceeded with
    # assumptions, or may ask once more -- print whatever comes back.
    if resp2.status == "clarifying_question":
        resp3 = run_turn(deps, channel="copilot", external_conversation_id=conv_id, user_id="user-3",
                          user_message="I don't have more detail, just show me something.")
        print_response("Example 3, turn 3 (round cap reached)", resp3)


def example_4_ambiguous_intent_disambiguation():
    """Exercises the actual intent-disambiguation path: a query with real,
    competing signal (some 'template' language, some 'guideline' language)
    rather than no signal at all."""
    deps = build_dependencies(use_mock=True)
    conv_id = "conv-4"

    resp1 = run_turn(deps, channel="teams", external_conversation_id=conv_id, user_id="user-4",
                      user_message="Can I get a business card template, and what's the correct way to use our logo on it?")
    print_response("Example 4, turn 1 (competing template/guideline cues)", resp1)

    if resp1.status == "clarifying_question":
        resp2 = run_turn(deps, channel="teams", external_conversation_id=conv_id, user_id="user-4",
                          user_message="A template -- I need the actual editable file, not just the rule.")
        print_response("Example 4, turn 2 (user disambiguates directly)", resp2)


def example_5_people_profile_lookup():
    """Exercises the peopleOfficeProfile content profile end-to-end --
    intent classification via 'who is' cues, person_query slot extraction,
    and the reuse-KPI exclusion flag on the resulting card."""
    deps = build_dependencies(use_mock=True)
    resp = run_turn(
        deps, channel="copilot", external_conversation_id="conv-5", user_id="user-5",
        user_message="Who is Jane Whitfield, the office managing partner in Chicago?",
    )
    print_response("Example 5: people/office profile lookup", resp)
    if resp.result_cards:
        print(f"  counts_toward_reuse_kpi: {resp.result_cards[0].counts_toward_reuse_kpi}")


if __name__ == "__main__":
    example_1_well_specified()
    example_2_one_clarification_round()
    example_3_round_cap_hit()
    example_4_ambiguous_intent_disambiguation()
    example_5_people_profile_lookup()

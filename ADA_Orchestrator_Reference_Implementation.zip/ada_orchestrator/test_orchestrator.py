"""
Unit tests covering the logic that matters most to get right: the guided-
question round cap, the hybrid intent-gathering flow (automatic
classification + user disambiguation both landing in the same SlotState),
Cosmos-DB-driven ranking weights (never LLM-decided), and permission-check
suppression. Run with: python -m pytest test_orchestrator.py -v
(or `python test_orchestrator.py` for a plain assert-based run).
"""

from ada_orchestrator.clients.azure_openai_client import MockAzureOpenAIClient
from ada_orchestrator.clients.taxonomy_store import MockTaxonomyStore
from ada_orchestrator.models import CandidateAsset, DEFAULT_ROUND_CAP, SlotState, SlotValue
from ada_orchestrator.orchestrator import build_dependencies, run_turn
from ada_orchestrator.steps.step4_query_understanding import run_query_understanding
from ada_orchestrator.steps.step4a_guided_questions import run_guided_question_step
from ada_orchestrator.steps.step4b_source_priority import resolve_profile_boosts, resolve_source_weights
from ada_orchestrator.steps.step7_live_permission_check import MockPermissionChecker, apply_live_permission_check
from ada_orchestrator.steps.step8_ranking_explanation import rank_candidates


def test_round_cap_is_respected():
    llm = MockAzureOpenAIClient()
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()  # nothing filled -- everything relevant is missing

    for expected_round in range(1, DEFAULT_ROUND_CAP + 1):
        should_ask, question = run_guided_question_step(llm, taxonomy, slot_state)
        assert should_ask is True, f"expected a question at round {expected_round}"
        assert slot_state.round_count == expected_round

    # Round cap now reached -- next call must NOT ask again, and must mark assumptions.
    should_ask, question = run_guided_question_step(llm, taxonomy, slot_state)
    assert should_ask is False
    assert question is None
    assert slot_state.assumptions_made is True
    print("test_round_cap_is_respected: PASS")


def test_no_question_when_all_relevant_slots_filled():
    llm = MockAzureOpenAIClient()
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="assetReuse", confidence="high", source="stated")
    for name in ("user_role", "asset_format", "asset_subject", "destination_use", "audience", "market"):
        slot_state.slots[name] = SlotValue(value="x", confidence="high", source="stated")

    should_ask, question = run_guided_question_step(llm, taxonomy, slot_state)
    assert should_ask is False
    assert question is None
    print("test_no_question_when_all_relevant_slots_filled: PASS")


def test_query_intent_classified_from_cosmos_cues_not_hardcoded():
    """The mock LLM's classification must come from the detection cues
    TaxonomyStore provides, not a hardcoded category list -- swapping the
    cue set should change the classification, proving the cues are actually
    being read from context rather than baked into the mock."""
    llm = MockAzureOpenAIClient()
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()

    run_query_understanding(llm, taxonomy, "I need a template for a business card", slot_state)
    assert slot_state.query_intent.value == "templateRequest", slot_state.query_intent
    print("test_query_intent_classified_from_cosmos_cues_not_hardcoded: PASS")


def test_ambiguous_intent_triggers_disambiguation_not_slot_question():
    """When query_intent is set but low-confidence, Step 4a should ask about
    the intent itself (target_slot == 'query_intent'), not about a generic
    W/X/Y/Z slot -- this is the 'hybrid' behavior the client asked for."""
    llm = MockAzureOpenAIClient()
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="templateRequest", confidence="low", source="inferred")

    should_ask, question = run_guided_question_step(llm, taxonomy, slot_state)
    assert should_ask is True
    assert question.slot == "query_intent"
    print("test_ambiguous_intent_triggers_disambiguation_not_slot_question: PASS")


def test_user_answer_overrides_inferred_intent():
    """The 'ask the user' path must be able to set query_intent directly and
    have it win -- this is the other half of the hybrid: a stated answer
    beats an automatically inferred (and possibly wrong) classification."""
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="templateRequest", confidence="low", source="inferred")
    slot_state.set_query_intent_from_user_answer("brandGuidelineLookup")
    assert slot_state.query_intent.value == "brandGuidelineLookup"
    assert slot_state.query_intent.source == "stated"
    assert slot_state.query_intent.confidence == "high"
    print("test_user_answer_overrides_inferred_intent: PASS")


def test_profile_boosts_come_from_cosmos_matrix_not_llm():
    """resolve_profile_boosts must return EXACTLY the matrix values held in
    Cosmos DB (mocked here) for a given intent -- no LLM involved, no
    randomness, no free-form weight the model could invent."""
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="templateRequest", confidence="high", source="stated")

    boosts = resolve_profile_boosts(taxonomy, slot_state)
    expected = taxonomy.get_intent_profile_boost()["templateRequest"]
    assert boosts == expected, f"{boosts} != {expected}"

    source_weights = resolve_source_weights(taxonomy, slot_state)
    assert source_weights["SharePoint"] == expected["brandGuidelineReference"]
    assert source_weights["AdobeDAM"] == expected["creativeAsset"]
    print("test_profile_boosts_come_from_cosmos_matrix_not_llm: PASS")


def test_template_link_boost_only_applies_to_matching_profile_and_intent():
    taxonomy = MockTaxonomyStore()
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="templateRequest", confidence="high", source="stated")
    slot_state.slots["asset_subject"] = SlotValue(value=None)

    with_template = CandidateAsset(
        asset_id="a", title="t", title_source="source", description="d", description_source="source",
        source_system="SharePoint", source_url="u", asset_type="template", content_profile="brandGuidelineReference",
        relevance_score=1.0, has_template_link=True, is_template_link_current=True,
    )
    without_template = CandidateAsset(
        asset_id="b", title="t2", title_source="source", description="d2", description_source="source",
        source_system="SharePoint", source_url="u2", asset_type="document", content_profile="brandGuidelineReference",
        relevance_score=1.0, has_template_link=False,
    )
    ranked = rank_candidates(taxonomy, [without_template, with_template], slot_state)
    assert ranked[0].asset_id == "a", "asset with a current template link should outrank one without, for a templateRequest"
    print("test_template_link_boost_only_applies_to_matching_profile_and_intent: PASS")


def test_people_profile_excluded_from_reuse_kpi():
    from ada_orchestrator.steps.step8_ranking_explanation import generate_result_cards

    taxonomy = MockTaxonomyStore()
    llm = MockAzureOpenAIClient()
    slot_state = SlotState()
    slot_state.query_intent = SlotValue(value="peopleProfileLookup", confidence="high", source="stated")

    person_asset = CandidateAsset(
        asset_id="cf-1", title="Jane Doe", title_source="source", description="Partner", description_source="source",
        source_system="ContentFragment", source_url="u", asset_type="profile",
        content_profile="peopleOfficeProfile", relevance_score=3.0,
        first_name="Jane", last_name="Doe", job_title="Partner", office_location="Chicago",
    )
    ranked = rank_candidates(taxonomy, [person_asset], slot_state)
    cards = generate_result_cards(llm, ranked, slot_state)
    assert cards[0].counts_toward_reuse_kpi is False
    print("test_people_profile_excluded_from_reuse_kpi: PASS")


def test_permission_check_suppresses_restricted_assets():
    checker = MockPermissionChecker()
    restricted = CandidateAsset(
        asset_id="x", title="t", title_source="source", description="d", description_source="source",
        source_system="SharePoint", source_url="u", asset_type="doc", restricted_flag=True,
    )
    allowed = CandidateAsset(
        asset_id="y", title="t2", title_source="source", description="d2", description_source="source",
        source_system="SharePoint", source_url="u2", asset_type="doc", restricted_flag=False,
    )
    result = apply_live_permission_check(checker, "user-1", [restricted, allowed])
    assert [c.asset_id for c in result] == ["y"]
    print("test_permission_check_suppresses_restricted_assets: PASS")


def test_full_turn_never_raises_and_returns_valid_status():
    deps = build_dependencies(use_mock=True)
    resp = run_turn(
        deps, channel="teams", external_conversation_id="test-conv-2", user_id="test-user-2",
        user_message="I am a designer looking for an image about AI transformation for an ey.com webpage.",
    )
    assert resp.status in ("clarifying_question", "results")
    print("test_full_turn_never_raises_and_returns_valid_status: PASS")


def test_coded_agent_handler_dispatches_by_step_name():
    """
    Exercises foundry_coded_agent/handler.py's routing logic directly --
    the part of the Foundry integration that runs server-side, inside the
    Coded Agent, rather than in the orchestrator process.
    """
    import json
    from ada_orchestrator import prompts as _prompts, tools as _tools
    from foundry_coded_agent.handler import _STEP_TOOL_MAP

    all_tool_names = {
        _tools.EXTRACT_INTENT_TOOL["function"]["name"],
        _tools.ASK_CLARIFYING_QUESTION_TOOL["function"]["name"],
        _tools.WRITE_RATIONALE_TOOL["function"]["name"],
        _tools.WRITE_CONFIRMATION_PROMPT_TOOL["function"]["name"],
    }
    assert set(_STEP_TOOL_MAP.keys()) == all_tool_names, (
        "foundry_coded_agent/handler.py's _STEP_TOOL_MAP is out of sync with tools.py"
    )

    from foundry_coded_agent.handler import handle_message

    bad_payload = json.dumps({
        "step": "extract_intent",
        "system_prompt": _prompts.QUERY_UNDERSTANDING_SYSTEM_PROMPT,
        "tool_schema": {"function": {"name": "some_other_tool"}},
        "user_message": "test",
        "context": {},
    })
    try:
        handle_message(bad_payload)
        raised = False
    except RuntimeError:
        raised = True
    assert raised, "handle_message() should reject a mismatched tool_schema, not proceed silently"
    print("test_coded_agent_handler_dispatches_by_step_name: PASS")


if __name__ == "__main__":
    test_round_cap_is_respected()
    test_no_question_when_all_relevant_slots_filled()
    test_query_intent_classified_from_cosmos_cues_not_hardcoded()
    test_ambiguous_intent_triggers_disambiguation_not_slot_question()
    test_user_answer_overrides_inferred_intent()
    test_profile_boosts_come_from_cosmos_matrix_not_llm()
    test_template_link_boost_only_applies_to_matching_profile_and_intent()
    test_people_profile_excluded_from_reuse_kpi()
    test_permission_check_suppresses_restricted_assets()
    test_full_turn_never_raises_and_returns_valid_status()
    test_coded_agent_handler_dispatches_by_step_name()
    print("\nAll tests passed.")

"""
ADA Coded Agent -- the server-side implementation registered in Azure AI
Foundry Agent Service as ADA's dedicated agent (architecture diagram:
"AI Foundry Agent Service (Foundry Threads)" feeding the ADA Orchestrator,
Section 4.1's "AI Orchestration" row: "Per-agent orchestration (ADA, CGE,
SBA...)" -> "Azure AI Foundry Agent Service, Microsoft Agent Framework").

This module is a SEPARATE deployable unit from the rest of this package. It
does not run inside the Azure Function (`function_app.py`); it is what
Foundry invokes when the orchestrator's FoundryCodedAgentClient
(clients/foundry_agent_client.py) creates a Run against this agent's id.

Why a "Coded Agent" rather than a plain prompt+tools Foundry agent: ADA needs
five distinct system prompts/tool schemas depending on which orchestrator
step is calling (Query Understanding, Guided Question, Source Prioritization,
Ranking+Explanation, Result Confirmation) -- a single static Foundry agent
definition (one instructions field, one toolset) can't switch behavior per
call. A Coded Agent lets us keep that per-step routing as our own code,
while still gaining Foundry's Thread persistence and observability
(Section 4.2: "Observability & Audit -> Foundry observability") around every
call.

Deployment note: exactly how a Python callable is registered as a Foundry
Coded Agent depends on the Foundry SDK/tooling version in use at deploy time
(custom/"bring your own code" agents are a newer Agent Service capability).
The important, stable contract is the function signature below:
`handle_message(payload: dict) -> dict`, matching what
FoundryCodedAgentClient.call_tool() sends and expects back.
"""

from __future__ import annotations

import json
from typing import Any

# Reuse the exact same prompts/tools the orchestrator's own mock/direct-OpenAI
# path uses (ada_orchestrator/prompts.py, ada_orchestrator/tools.py) so the
# Coded Agent's behavior can never silently drift from what's documented and
# governance-reviewed in one place. In a real deployment this package is
# installed as a dependency of the Foundry Coded Agent's runtime, not copied.
from ada_orchestrator import prompts as _prompts
from ada_orchestrator import tools as _tools


# Maps each tool/function name (Step's contract) to the model call that
# actually performs the reasoning. In production this calls the Azure OpenAI
# GPT deployment shown in the architecture diagram as the model behind the
# AI Orchestration layer -- the Coded Agent's code is "coded" in the sense
# that WE control this dispatch and prompt selection; it still ultimately
# calls an LLM, exactly as RealAzureOpenAIClient does client-side.
def _call_underlying_model(system_prompt: str, user_message: str, tool_schema: dict, context: dict) -> dict[str, Any]:
    from ada_orchestrator.clients.azure_openai_client import RealAzureOpenAIClient
    from ada_orchestrator import config

    client = RealAzureOpenAIClient(
        endpoint=config.AZURE_OPENAI_ENDPOINT,
        api_key=config.AZURE_OPENAI_API_KEY,
        chat_deployment=config.FOUNDRY_MODEL_DEPLOYMENT,
        embedding_deployment=config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
        api_version=config.AZURE_OPENAI_API_VERSION,
    )
    return client.call_tool(system_prompt, user_message, tool_schema, context)


_STEP_TOOL_MAP = {
    "extract_intent": (_prompts.QUERY_UNDERSTANDING_SYSTEM_PROMPT, _tools.EXTRACT_INTENT_TOOL),
    "ask_clarifying_question": (_prompts.GUIDED_QUESTION_SYSTEM_PROMPT, _tools.ASK_CLARIFYING_QUESTION_TOOL),
    "write_rationale": (_prompts.RANKING_EXPLANATION_SYSTEM_PROMPT, _tools.WRITE_RATIONALE_TOOL),
    "write_confirmation_prompt": (_prompts.RESULT_CONFIRMATION_SYSTEM_PROMPT, _tools.WRITE_CONFIRMATION_PROMPT_TOOL),
}
# NOTE: "set_source_weights" intentionally removed -- source/content-profile
# prioritization is a deterministic Cosmos DB matrix lookup
# (steps/step4b_source_priority.py), never an LLM call, so this Coded Agent
# has no step for it. query_intent classification (which DOES feed that
# lookup) is handled inside "extract_intent" above.


def handle_message(raw_message_content: str) -> dict[str, Any]:
    """
    Entry point Foundry calls (via whatever adapter its Coded Agent runtime
    uses to invoke Python code) when a Run is created against this agent on
    a message the orchestrator posted. `raw_message_content` is the JSON
    string FoundryCodedAgentClient.call_tool() wrote to the Thread.

    Returns the same shape the orchestrator's steps/*.py modules already
    expect from any LLMClient.call_tool() -- the parsed function-call
    arguments dict -- so nothing downstream of the client needs to know
    whether it was mocked, called Azure OpenAI directly, or ran through this
    Coded Agent.
    """
    payload = json.loads(raw_message_content)
    step_name = payload["step"]

    if step_name not in _STEP_TOOL_MAP:
        raise ValueError(f"ADA Coded Agent received unknown step '{step_name}'")

    system_prompt, tool_schema = _STEP_TOOL_MAP[step_name]

    # Defensive check: the orchestrator sends its own copy of the prompt/tool
    # schema alongside the step name (see foundry_agent_client.py's payload).
    # If they've drifted from this agent's bundled copy, fail loudly rather
    # than silently using a stale prompt -- governance sign-off in prompts.py
    # is meaningless if the deployed agent can quietly diverge from it.
    if payload.get("tool_schema", {}).get("function", {}).get("name") != tool_schema["function"]["name"]:
        raise RuntimeError(
            f"Tool schema mismatch for step '{step_name}' -- orchestrator and "
            f"Coded Agent are running different versions of tools.py. Redeploy "
            f"in lockstep before serving traffic."
        )

    return _call_underlying_model(
        system_prompt=system_prompt,
        user_message=payload["user_message"],
        tool_schema=tool_schema,
        context=payload.get("context", {}),
    )

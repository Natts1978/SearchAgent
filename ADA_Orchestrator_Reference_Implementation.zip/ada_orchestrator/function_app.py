"""
Azure Functions (Python v2 programming model) entry point -- Step 3, "ADA
Orchestrator Entry". This is the ONLY HTTP surface the orchestrator exposes;
Teams and Copilot connectors both call this same endpoint (Solution Approach
Section 2.3.4 -- channel-agnostic single codebase).

Deploy with `func azure functionapp publish <app-name>` after configuring
the environment variables listed in ada_orchestrator/config.py (Azure App
Configuration / Key Vault references in production, per Section 2.2).
"""

import json
import logging

import azure.functions as func

from ada_orchestrator import config
from ada_orchestrator.orchestrator import build_dependencies, run_turn

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

# Built once per host instance -- real Azure SDK clients are safe to reuse
# across invocations; swap config.USE_MOCK_CLIENTS for production traffic.
_DEPENDENCIES = build_dependencies(use_mock=config.USE_MOCK_CLIENTS)


@app.route(route="ada/orchestrator", methods=["POST"])
def ada_orchestrator_entry(req: func.HttpRequest) -> func.HttpResponse:
    """
    Expected request body (from the Teams/Copilot/custom-portal connector,
    already authenticated by APIM + Microsoft Entra ID upstream -- see
    Step 3 in the confirmed flow):

    {
        "channel": "teams" | "copilot" | "custom_portal",
        "external_conversation_id": "<channel-native conversation id>",
        "user_id": "<Entra object id>",
        "message": "<user's natural-language message>",
        "market": "US"   // optional, from user profile if not yet known
    }
    """
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse("Invalid JSON body", status_code=400)

    required = ["channel", "external_conversation_id", "user_id", "message"]
    missing = [f for f in required if f not in body]
    if missing:
        return func.HttpResponse(f"Missing required fields: {missing}", status_code=400)

    try:
        response = run_turn(
            deps=_DEPENDENCIES,
            channel=body["channel"],
            external_conversation_id=body["external_conversation_id"],
            user_id=body["user_id"],
            user_message=body["message"],
            market=body.get("market"),
        )
    except Exception:
        logging.exception("ADA orchestrator error")
        return func.HttpResponse("Internal error", status_code=500)

    return func.HttpResponse(
        json.dumps(_response_to_dict(response), default=str),
        status_code=200,
        mimetype="application/json",
    )


def _response_to_dict(response) -> dict:
    result = {
        "correlationId": response.correlation_id,
        "threadId": response.thread_id,
        "status": response.status,
    }
    if response.clarifying_question:
        result["clarifyingQuestion"] = {
            "slot": response.clarifying_question.slot,
            "questionText": response.clarifying_question.question_text,
            "options": response.clarifying_question.options,
        }
    if response.result_cards:
        result["resultCards"] = [
            {
                "assetId": c.asset_id, "title": c.title,
                "titleFlaggedAiGenerated": c.title_flagged_ai_generated,
                "description": c.description,
                "descriptionFlaggedAiGenerated": c.description_flagged_ai_generated,
                "sourceSystem": c.source_system, "sourceUrl": c.source_url,
                "approvalStatus": c.approval_status, "lifecycleStatus": c.lifecycle_status,
                "owner": c.owner, "recommendationRationale": c.recommendation_rationale,
            }
            for c in response.result_cards
        ]
    if response.confirmation_prompt:
        result["confirmationPrompt"] = response.confirmation_prompt
    result["assumptionsMade"] = response.assumptions_made
    return result
